//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Skinner.rc
//
#if _MSC_VER<=1310
#define IDR_MANIFEST               1
#endif
#define IDD_SKINNERDLG                  2005
#define IDC_MAINTOOLBAR                 2006
#define IDC_STATIC_SECTION              2007
#define IDC_SECTIONS                    2008
#define IDC_GROUPS                      2009
#define IDC_ENTRYLIST                  2010
#define IDC_ICONLIST                 2011
#define IDD_SKINNER_PREFS               3005
#define IDC_EXT_OPTS                    3006
#define IDC_PREFSWARNING                   3007
#define IDD_ICONDIALOG                 4005
#define IDBROWSE                        4006
#define IDC_FILENAME                    4007
#define IDC_STATIC_FILENAME        4009
#define IDC_STATIC_CURRENTICON         4010


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
