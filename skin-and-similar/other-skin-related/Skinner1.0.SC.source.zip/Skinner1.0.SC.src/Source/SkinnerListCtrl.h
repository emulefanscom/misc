//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once
#include "MenuEx.h"

class CSkinnerListCtrl : public CListCtrl
{
 public:
	CSkinnerListCtrl();
	virtual ~CSkinnerListCtrl();

	void InitListCtrl();
	void Localize();
	void InsertItem(const CString& strEntry, const CString& strValue, DWORD_PTR dwData = NULL);
	void SetValueType(const CString& strValType) { m_strValType = strValType; }
	const CString& GetValueType() const { return m_strValType; }
	CEdit* GetEditCtrl() const { return m_pEdit; }
	void CommitEditCtrl();

	enum {
		colEntry = 0,
		colValue = 1
	};

 protected:
	void SetAllIcons();
	int GetDisplayIconIndex(const CString& strEntry);
	void CreateMenues();
	CMenuEx m_menuEntry;
	CImageList m_iconList;
	CMap<CString, LPCTSTR, int, int> m_idxIcons;

	CString m_strValType;
	CEdit* m_pEdit;
	int m_iEditRow;
	int m_iEditCol;

	DECLARE_MESSAGE_MAP()

	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg LRESULT OnColorPopupEndOK(WPARAM wParam, LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
	afx_msg void OnEnKillFocus();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnLvnBeginScroll(NMHDR *pNMHDR, LRESULT *pResult);

	void ShowEditCtrl();
};
