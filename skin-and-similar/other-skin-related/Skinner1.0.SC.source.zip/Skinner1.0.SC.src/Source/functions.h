//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once

// convert
CString color2str(COLORREF color);
COLORREF str2color(LPCTSTR str);

// icons
bool GetIconFileIndex(CString& strIcon, int& nIndex);
bool DrawGrayIcon(HDC hdc, HICON hIcon, const CPoint& pt, bool bHover = false);

// zip/rar related code
bool IsArchiveFile(const CString& strFile);
bool ExtractSkin(CString& strSkinPackage, bool bSaveIniPath = false);
bool ExtractSkinZip(CString& strSkinPackage, bool bSaveIniPath = false);
bool ExtractSkinRar(CString& strSkinPackage, bool bSaveIniPath = false);

// version related
uint32 MakeVersion(const CString& strVer);
uint32 MakeVersion(uint8 nMjr = SKINNER_VERMJR, uint8 nMin = SKINNER_VERMIN, uint8 nUpdate = SKINNER_VERUPDATE);

// windows version related
#define _WINVER_UNKNOWN	0x0000	// v0.0
#define _WINVER_95		0x0040	// v4.0
#define _WINVER_98		0x0041	// v4.10
#define _WINVER_ME		0x0049	// v4.90
#define _WINVER_NT4		0x0400	// v4.0
#define _WINVER_2K		0x0500	// v5.0
#define _WINVER_XP		0x0510	// v5.1
#define _WINVER_2K3		0x0520	// v5.2
#define _WINVER_VISTA		0x0600	// v6.0

DWORD DetectWinVersion();

// eMule folder & related things
CString FindMulePath();
DWORD DetectMuleDirMod();
CString GetMuleConfigFilePath(DWORD nDirMode = -2);

// skin extensions
bool IsSkinFile(const CString& strFilename, bool bOldExts = false);
bool HasSkinfileRegAccess();
bool ApplySkinfileReg(bool bReg = true);

// others
int GetAppImageListColorFlag();
bool ReadNetFile(const CString& strURL, CArray<char>& aData);

