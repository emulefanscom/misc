//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "Skinner.h"
#include "functions.h"
#include "ini2.h"
#include "Preferences.h"
#include "ZipFile.h"
#include "RarFile.h"
#include "StringConversion.h"
#include <atlenc.h>
#include <share.h>
#include <io.h>


CString color2str(COLORREF color)
{
	CString tmp;
	tmp.Format(_T("%i, %i, %i"), GetRValue(color), GetGValue(color), GetBValue(color));
	return tmp;
}

COLORREF str2color(LPCTSTR str)
{
	if (!str || str[0] == _T('\0'))
		return RGB(255, 255, 255);

	UINT red, green, blue;
	if (_stscanf(str, _T("%i, %i, %i"), &red, &green, &blue) == 3)
		return RGB(red, green, blue);
	return RGB(255, 255, 255);
}


bool GetIconFileIndex(CString& strIcon, int& nIndex)
{
	int pos = strIcon.ReverseFind(_T(','));
	if (pos < 1)
		return false;
	nIndex = _tstoi(strIcon.Mid(pos+1));
	strIcon = strIcon.Left(pos);
	CString ext = strIcon.Right(4).MakeLower();
	return (ext == _T(".icl") || ext == _T(".exe") || ext == _T(".dll") || ext == _T(".ocx"));
}

#ifndef COLOR_MENUHILIGHT
#define COLOR_MENUHILIGHT 29
#endif

bool DrawGrayIcon(HDC hdc, HICON hIcon, const CPoint& pt, bool bHover)
{
	CImage img, imgGray;
	if (!img.Create(16, 16, 32, CImage::createAlphaChannel) || !imgGray.Create(16, 16, 32, CImage::createAlphaChannel))
		return false;
	//DrawIcon(img.GetDC(), 0, 0, hIcon);
	DrawIconEx(img.GetDC(), 0, 0, hIcon, imgGray.GetWidth(), imgGray.GetHeight(), 0, NULL, DI_NORMAL);
	for (int x = 0; x < imgGray.GetWidth(); x++)
	{
		for (int y = 0; y < imgGray.GetHeight(); y++)
		{
			COLORREF cr = img.GetPixel(x, y);
			byte byGray = (byte)(0.3 * GetRValue(cr) + 0.55 * GetGValue(cr) + 0.15 * GetBValue(cr));
			imgGray.SetPixel(x, y, (byGray) ? RGB(byGray, byGray, byGray) : GetSysColor((bHover) ? COLOR_MENUHILIGHT : COLOR_MENU));
		}
	}
	imgGray.Draw(hdc, pt.x, pt.y, imgGray.GetWidth(), imgGray.GetHeight());
	img.ReleaseDC();
	return true;
}

bool IsArchiveFile(const CString& strFile)
{
	static const LPCTSTR _pszSkinsArchives[] = { _T(".zip"), _T(".rar"), _T(".") EMULESKIN_BASEEXT _T("zip"), _T(".") EMULESKIN_BASEEXT _T("rar") };
	for (int i = 0; i < ARRSIZE(_pszSkinsArchives); i++)
	{
		CString strExt = _pszSkinsArchives[i];
		if (!strFile.Right(strExt.GetLength()).CompareNoCase(strExt))
			return true;
	}
	return false;
}

bool ExtractSkin(CString& strSkinPackage, bool bSaveIniPath)
{
	//if (!IsArchiveFile(strSkinPackage)) // check the file is a skin archive file
	//	return false;
	if (!strSkinPackage.Right(3).CompareNoCase(_T("rar")))
		return ExtractSkinRar(strSkinPackage, bSaveIniPath);
	if (!strSkinPackage.Right(3).CompareNoCase(_T("zip")))
		return ExtractSkinZip(strSkinPackage, bSaveIniPath);
	return false;
}

// zip & rar extract functions (from eMule; modified)

bool ExtractSkinZip(CString& strSkinPackage, bool bSaveIniPath)
{
	static const TCHAR _szSkinSuffix[] = _T(".") EMULESKIN_BASEEXT _T(".ini");
	static const TCHAR _szSkinSuffixNew[] = _T(".") EMULESKIN_BASEEXT;

	CZIPFile zip;
	if (!zip.Open(strSkinPackage))
		return false;

	// Search the "*.eMuleSkin.ini" file..
	CZIPFile::File* zfIniFile = NULL;
	CZIPFile::File* zf = NULL;
	for (int i = 0; i < zip.GetCount(); i++)
	{
		zf = zip.GetFile(i);
		if (zf && (!zf->m_sName.Right(ARRSIZE(_szSkinSuffix)-1).CompareNoCase(_szSkinSuffix) ||
			!zf->m_sName.Right(ARRSIZE(_szSkinSuffixNew)-1).CompareNoCase(_szSkinSuffixNew)))
		{
			zfIniFile = zf;
			break;
		}
	}

	if (!zfIniFile || thePrefs.GetSkinProfileDir().IsEmpty() || _taccess(thePrefs.GetSkinProfileDir(), 0) != 0)
		return false;

	CString strPath;
	strPath.Format(_T("%s\\%s\\"), thePrefs.GetSkinProfileDir(), zfIniFile->m_sName.Left(zfIniFile->m_sName.GetLength()-ARRSIZE(_szSkinSuffix)+1));
	if (!CreateDirectory(strPath, 0))
		return false;
	bool bRet = true;
	for (int i = 0; i < zip.GetCount() && bRet; i++)
	{
		zf = zip.GetFile(i);
		if (!zf || zf->m_sName.IsEmpty() || zf->m_sName[0] == _T('\\') || zf->m_sName[0] == _T('/') ||
			zf->m_sName.Find(_T(':')) != -1 || zf->m_sName.Find(_T("..\\")) != -1 || zf->m_sName.Find(_T("../")) != -1)
				continue;
		CString strDstPath;
		if (zf->m_sName[zf->m_sName.GetLength()-1] == _T('/'))
		{
			PathCanonicalize(strDstPath.GetBuffer(MAX_PATH), strPath + zf->m_sName.Left(zf->m_sName.GetLength()-1));
			strDstPath.ReleaseBuffer();
			if (!CreateDirectory(strDstPath, NULL))
				bRet = false;
		}
		else
		{
				
			PathCanonicalize(strDstPath.GetBuffer(MAX_PATH), strPath + zf->m_sName);
			strDstPath.ReleaseBuffer();
			if (!zf->Extract(strDstPath))
				bRet = false;
		}
	}
	if (bSaveIniPath && bRet)
		strSkinPackage = strPath + zfIniFile->m_sName;
	zip.Close();
	return bRet;
}

bool ExtractSkinRar(CString& strSkinPackage, bool bSaveIniPath)
{
	static const TCHAR _szSkinSuffix[] = _T(".") EMULESKIN_BASEEXT _T(".ini");
	static const TCHAR _szSkinSuffixNew[] = _T(".") EMULESKIN_BASEEXT;

	CRARFile rar;
	if (!rar.Open(strSkinPackage))
		return false;

	bool bError = false;
	bool bFoundSkinINIFile = false;
	CString strFileName, strIniFile;
	while (rar.GetNextFile(strFileName))
	{
		if (strFileName.IsEmpty() || strFileName[0] == _T('\\') || strFileName[0] == _T('/') || strFileName.Find(_T(':')) != -1 ||
			strFileName.Find(_T("..\\")) != -1 || strFileName.Find(_T("../")) != -1)
		{
			rar.Skip();
			continue;
		}
		if (!bFoundSkinINIFile && (!strFileName.Right(ARRSIZE(_szSkinSuffix)-1).CompareNoCase(_szSkinSuffix) ||
			!strFileName.Right(ARRSIZE(_szSkinSuffixNew)-1).CompareNoCase(_szSkinSuffixNew)))
		{
			strIniFile = strFileName;
			bFoundSkinINIFile = true;
		}

		// No need to care about possible available sub-directories. UnRAR.DLL cares about that automatically.
		CString strDstFilePath;
		PathCanonicalize(strDstFilePath.GetBuffer(MAX_PATH), thePrefs.GetSkinProfileDir() + _T('\\') + strFileName);
		strDstFilePath.ReleaseBuffer();
		SetLastError(0);
		if (!rar.Extract(strDstFilePath))
		{
			bError = true;
			break;
		}
	}

	if (!bError && bFoundSkinINIFile && bSaveIniPath)
		strSkinPackage = thePrefs.GetSkinProfileDir() + _T("\\") + strIniFile;
	rar.Close();
	return !bError;
}

int GetAppImageListColorFlag()
{
	static int ilcFlag = ILC_COLOR16;
	static bool bFlagged = false;
	if (!bFlagged)
	{
		HDC hdcScreen = ::GetDC(HWND_DESKTOP);
		int iColorBits = GetDeviceCaps(hdcScreen, BITSPIXEL) * GetDeviceCaps(hdcScreen, PLANES);
		::ReleaseDC(HWND_DESKTOP, hdcScreen);
		if (iColorBits >= 32)
			ilcFlag = ILC_COLOR32;
		else if (iColorBits >= 24)
			ilcFlag = ILC_COLOR24;
		bFlagged = true;
	}
	return ilcFlag;
}

bool ReadNetFile(const CString& strURL, CArray<char>& aData)
{
	aData.RemoveAll();
	if (!thePrefs.usenetconns)
		return false;

	// --> Note: Do not change this part - Avi3k
	CString strFullURL = _T("http://hebmule.sourceforge.net/") + strURL;
#ifdef _DEBUG
	strFullURL = CString(_T("http://localhost/hebmule/")) + strURL;
#endif
	// end note

	CInternetSession session;
	CInternetFile* file = NULL;
	try
	{
		file = (CInternetFile*)session.OpenURL(strFullURL);
	}
	catch (CInternetException* e)
	{
		file = NULL;
		e->Delete();
		return false;
	}
	CArray<char> chBuffer;
	chBuffer.SetSize(MAX_STRLEN2+1);
	UINT nCount;
	while ((nCount = file->Read(chBuffer.GetData(), MAX_STRLEN2)) > 0)
	{
		chBuffer.SetSize(nCount);
		aData.Append(chBuffer);
		chBuffer.RemoveAll();
		chBuffer.SetSize(MAX_STRLEN2+1);
	}
	file->Close();
	delete file;
	file = NULL;
	return (aData.GetCount() > 0);
}


// eMule folder & related things
CString FindMulePath()
{
	static LPCTSTR _pszRegPaths[] = { _T("ed2k\\shell\\open\\command"), _T("emule\\shell\\open\\command") };
	CString strPath;
	CRegKey regkey;
	for (int i = 0; i < ARRSIZE(_pszRegPaths) && strPath.IsEmpty(); i++)
	{
		if (regkey.Open(HKEY_CLASSES_ROOT, _pszRegPaths[i]) == ERROR_SUCCESS)
		{
			TCHAR sBuffer[MAX_PATH];
			ULONG nLen = ARRSIZE(sBuffer);
			if (regkey.QueryStringValue(NULL, sBuffer, &nLen) == ERROR_SUCCESS)
			{
				CString strTempPath = CString(sBuffer).Left(nLen - 6);
				strTempPath.Replace(_T("\""), _T(""));
				if (!strTempPath.Trim().Right(4).CompareNoCase(_T(".exe")) && PathFileExists(strTempPath))
					strPath = strTempPath.Trim();
			}
			regkey.Close();
		}
	}
	return strPath;
}

DWORD DetectMuleDirMode()
{
	DWORD nDirMode = (DWORD)-1;
	CRegKey regkey;
	if (regkey.Open(HKEY_CURRENT_USER, _T("Software\\eMule")) == ERROR_SUCCESS)
		regkey.QueryDWORDValue(_T("UsePublicUserDirectories"), nDirMode);
	regkey.Close();
	return nDirMode;
}

#ifndef SHGFP_TYPE_CURRENT
#define SHGFP_TYPE_CURRENT	0
#endif

#ifdef DEFINE_KNOWN_FOLDER
#undef DEFINE_KNOWN_FOLDER
#endif

typedef GUID KNOWNFOLDERID;
#define REFKNOWNFOLDERID const KNOWNFOLDERID &

#define DEFINE_KNOWN_FOLDER(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
        EXTERN_C const GUID DECLSPEC_SELECTANY name = { l, w1, w2, { b1, b2,  b3,  b4,  b5,  b6,  b7,  b8 } }

// {62AB5D82-FDC1-4DC3-A9DD-070D1D495D97}
DEFINE_KNOWN_FOLDER(FOLDERID_ProgramData,         0x62AB5D82, 0xFDC1, 0x4DC3, 0xA9, 0xDD, 0x07, 0x0D, 0x1D, 0x49, 0x5D, 0x97);

// {F1B32785-6FBA-4FCF-9D55-7B8E7F157091}
DEFINE_KNOWN_FOLDER(FOLDERID_LocalAppData,        0xF1B32785, 0x6FBA, 0x4FCF, 0x9D, 0x55, 0x7B, 0x8E, 0x7F, 0x15, 0x70, 0x91);


CString GetMuleConfigFilePath(DWORD nDirMode) // based on eMule's own code...
{
	if (!(nDirMode == -1 || (nDirMode >= 0 && nDirMode <= 2)))
		nDirMode = DetectMuleDirMode();

	CString strPath;
	if (nDirMode == -1 || nDirMode == 2) // either unset or exe-dir
	{
		int nPos = -1;
		strPath = thePrefs.strMulePath;
		if (strPath.IsEmpty() || (nPos = strPath.ReverseFind(_T('\\'))) < 1)
			return _T(""); // there's no known path
		strPath = strPath.Left(nPos+1) + _T("config\\preferences.ini");
		if (!PathFileExists(strPath))
			strPath.Empty();
		return strPath;
	}

	HMODULE hShell32 = LoadLibrary(_T("shell32.dll"));
	if (hShell32 == NULL)
		return GetMuleConfigFilePath(2); // check exe-dir

	HRESULT (WINAPI *pfnSHGetKnownFolderPath)(REFKNOWNFOLDERID, DWORD, HANDLE, PWSTR*);
	(FARPROC&)pfnSHGetKnownFolderPath = GetProcAddress(hShell32, "SHGetKnownFolderPath");
	HRESULT (WINAPI* pfnSHGetFolderPathW)(HWND, int, HANDLE, DWORD, LPWSTR);
	(FARPROC&)pfnSHGetFolderPathW = GetProcAddress(hShell32, "SHGetFolderPathW");
	PWSTR pszLocalAppData = NULL;
	PWSTR pszProgrammData = NULL;
	WCHAR wchAppData[MAX_PATH];

	if (pfnSHGetKnownFolderPath != NULL	&& (*pfnSHGetKnownFolderPath)(FOLDERID_LocalAppData, 0, NULL, &pszLocalAppData) == S_OK &&
		(*pfnSHGetKnownFolderPath)(FOLDERID_ProgramData, 0, NULL, &pszProgrammData) == S_OK)
	{
		CString strLocalAppData  = pszLocalAppData;
		CString strProgrammData = pszProgrammData;
		if (strLocalAppData.Right(1) != _T("\\"))
			strLocalAppData += _T("\\");
		if (strProgrammData.Right(1) != _T("\\"))
			strProgrammData += _T("\\");

		strPath = strLocalAppData + _T("eMule\\config\\preferences.ini");
		if (!PathFileExists(strPath))
			strPath = strProgrammData + _T("eMule\\config\\preferences.ini");
		if (!PathFileExists(strPath))
			strPath.Empty();

		CoTaskMemFree(pszLocalAppData);
		CoTaskMemFree(pszProgrammData);
	}
	else if (pfnSHGetFolderPathW != NULL && (*pfnSHGetFolderPathW)(NULL, CSIDL_APPDATA, NULL, SHGFP_TYPE_CURRENT, wchAppData) == S_OK)
	{
		CString strAppData = wchAppData;
		if (strAppData.Right(1) != _T("\\"))
			strAppData += _T("\\");

		strPath = strAppData + _T("eMule\\config\\preferences.ini");
		if (!PathFileExists(strPath))
			strPath.Empty();
	}
	FreeLibrary(hShell32);
	if (strPath.IsEmpty())
		return GetMuleConfigFilePath(2); // check exe-dir
	return strPath;
}

// skins extension

bool IsSkinFile(const CString& strFilename, bool bOldExts)
{
	static const LPCTSTR _pszSkinsFiles[] = { _T(".") EMULESKIN_BASEEXT, _T(".") EMULESKIN_BASEEXT _T("zip"), _T(".") EMULESKIN_BASEEXT _T("rar") };
	static const LPCTSTR _pszSkinsOldFiles[] = { _T(".") EMULESKIN_BASEEXT _T(".ini"), _T(".") EMULESKIN_BASEEXT _T(".zip"), _T(".") EMULESKIN_BASEEXT _T(".rar") };
	for (int i = 0; i < ARRSIZE(_pszSkinsFiles); i++)
	{
		CString strExt = _pszSkinsFiles[i];
		if (!strFilename.Right(strExt.GetLength()).CompareNoCase(strExt))
			return true;
	}
	if (bOldExts)
	{
		for (int k = 0; k < ARRSIZE(_pszSkinsOldFiles); k++)
		{
			CString strExt = _pszSkinsOldFiles[k];
			if (!strFilename.Right(strExt.GetLength()).CompareNoCase(strExt))
				return true;
		}
	}
	return false;
}

bool HasSkinfileRegAccess()
{
	CRegKey regkey;
	bool bRet = (regkey.Create(HKEY_CLASSES_ROOT, _T("eMuleSkinFile")) == ERROR_SUCCESS);
	regkey.Close();
	return bRet;
}

bool ApplySkinfileReg(bool bReg)
{
	static const LPCTSTR _pszSkinsFiles[] = { _T(".") EMULESKIN_BASEEXT, _T(".") EMULESKIN_BASEEXT _T("zip"), _T(".") EMULESKIN_BASEEXT _T("rar") };
	if (!HasSkinfileRegAccess())
		return false;

	CRegKey regkey;
	if (!bReg)
	{
		regkey.Open(HKEY_CLASSES_ROOT, _T("eMuleSkinFile\\shell\\edit"));
		regkey.RecurseDeleteKey(_T("ddexec"));
		regkey.RecurseDeleteKey(_T("ddeexec"));
		regkey.Close();
		return true;
	}
	bool bSuccess = true;
	TCHAR sbuffer[MAX_PATH], regbuffer[MAX_PATH];
	::GetModuleFileName(NULL, sbuffer, ARRSIZE(sbuffer));
	CString strCanonFileName = sbuffer;
	strCanonFileName.Replace(_T("%"), _T("%%"));
	if (regkey.Create(HKEY_CLASSES_ROOT, _T("eMuleSkinFile\\shell\\edit\\command")) == ERROR_SUCCESS)
	{
		_sntprintf(regbuffer, ARRSIZE(regbuffer), _T("\"%s\" \"%%1\""), strCanonFileName);
		bSuccess = (regkey.SetStringValue(NULL, regbuffer) == ERROR_SUCCESS);
	}
	regkey.Close();
	if (regkey.Create(HKEY_CLASSES_ROOT, _T("eMuleSkinFile\\DefaultIcon")) == ERROR_SUCCESS)
		regkey.SetStringValue(NULL, strCanonFileName + _T(",2"));
	regkey.Close();
	if (regkey.Open(HKEY_CLASSES_ROOT, _T("eMuleSkinFile\\shell\\")) == ERROR_SUCCESS)
		regkey.SetStringValue(NULL, _T("open")); // set default action "open" for eMule
	regkey.Close();
	for (int i = 0; i < ARRSIZE(_pszSkinsFiles); i++)
	{
		if (regkey.Create(HKEY_CLASSES_ROOT, _pszSkinsFiles[i]) == ERROR_SUCCESS)
			bSuccess = bSuccess && (regkey.SetStringValue(NULL, _T("eMuleSkinFile")) == ERROR_SUCCESS);
		regkey.Close();
	}
	return bSuccess;
}

// version functions

uint32 MakeVersion(const CString& strVer)
{
	UINT nMjr = 0, nMin = 0;
	TCHAR chUpdate = 0;
	int nCount = (int)_stscanf(strVer, _T("%u.%u%c"), &nMjr, &nMin, &chUpdate);
	if (nCount < 2)
		return 0;
	if (nCount == 2)
		chUpdate = _T('a');
	else if (_istupper(chUpdate))
		chUpdate = _totlower(chUpdate);
	return MakeVersion((uint8)nMjr, (uint8)nMin, (uint8)(chUpdate - _T('a')));
}

uint32 MakeVersion(uint8 nMjr, uint8 nMin, uint8 nUpdate)
{
	return (uint32)(nMjr * 0x1000 + nMin * 0x100 + nUpdate); // stay compatible to hebMule-Onyx version check
}

DWORD DetectWinVersion()
{
	OSVERSIONINFOEX osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	if (!GetVersionEx((OSVERSIONINFO*)&osvi))
	{
		osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
		if (!GetVersionEx((OSVERSIONINFO*)&osvi)) 
			return _WINVER_UNKNOWN;
	}

	if (osvi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) // win9x
	{
		DWORD dwVer = ((osvi.dwMajorVersion & 0x0F) << 4) | ((osvi.dwMinorVersion / 10) & 0x0F);
		if (dwVer != _WINVER_98 && dwVer != _WINVER_ME)
			dwVer = _WINVER_95;
		return dwVer;
	}
	if (osvi.dwPlatformId != VER_PLATFORM_WIN32_NT) // be careful...
		return _WINVER_95;
	if (osvi.dwMajorVersion <= 4) // nt4
		return _WINVER_NT4;
	// nt: win2k/xp/2k3/vista...
	DWORD dwVer = ((osvi.dwMajorVersion & 0x0F) << 8) | ((osvi.dwMinorVersion & 0x0F) << 4) | (osvi.wServicePackMajor & 0x0F);
	DWORD dwVerMjr = dwVer & 0x0FF0;
	if (dwVerMjr != _WINVER_2K && dwVerMjr != _WINVER_XP && dwVerMjr != _WINVER_2K3 && dwVerMjr != _WINVER_VISTA)
		dwVer = _WINVER_NT4;
	return dwVer;
}
