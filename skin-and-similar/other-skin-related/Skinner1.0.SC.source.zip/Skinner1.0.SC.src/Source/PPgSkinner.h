//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once
#include "TreeOptionsCtrlEx.h"
#include "Resource.h"
#include "Lang.h"

class CPPgSkinner : public CPropertyPage
{
	DECLARE_DYNAMIC(CPPgSkinner)

 public:
	CPPgSkinner();
	virtual ~CPPgSkinner();

	void Localize();

 // Dialog Data
	enum { IDD = IDD_SKINNER_PREFS };

 protected:
	int m_iLangIndex;
	CString m_sLangName;
	bool m_bConfirmExit;
	CString m_sMulePath;
	bool m_bUseNetConns;
	bool m_bCheck4Update;
	CString m_sSkinName;
	CString m_sSkinProfile;
	CString m_sSkinProfileDir;
	bool m_bSkinProfileLoaded;
	bool m_bSkinProfileSaved;
	bool m_abMods[_aModsSize];

	CTreeOptionsCtrlEx m_ctrlTreeOptions;
	bool m_bInitializedTreeOpts;
	HTREEITEM m_htiLang;
	HTREEITEM m_htiConfirmExit;
	HTREEITEM m_htiMulePath;
	HTREEITEM m_htiNetConnsPrefs;
	HTREEITEM m_htiUseNetConns;
	HTREEITEM m_htiCheck4Update;
	HTREEITEM m_htiSkinProfilePrefs;
	HTREEITEM m_htiSkinName;
	HTREEITEM m_htiSkinProfile;
	HTREEITEM m_htiSkinProfileDir;
	HTREEITEM m_htiSkinProfileLoaded;
	HTREEITEM m_htiSkinProfileSaved;
	HTREEITEM m_htiModCompatPrefs;
	HTREEITEM m_ahtiMods[_aModsSize];

	CLangArray m_langs;
	bool m_bLangUpdated;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual BOOL OnApply();
	virtual BOOL OnKillActive();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnDestroy();
	afx_msg LRESULT OnTreeOptsCtrlNotify(WPARAM wParam, LPARAM lParam);

	void TreeItemsToNull();
};
