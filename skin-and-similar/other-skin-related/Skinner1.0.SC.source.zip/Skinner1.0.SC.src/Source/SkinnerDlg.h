//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once
#include "Skin.h"
#include "Skinner.h"
#include "Resource.h"
#include "SkinnerListCtrl.h"
#include "SkinnerToolBarCtrl.h"

class CPreferencesDlg;

class CSkinnerDlg : public CDialog
{
	DECLARE_DYNAMIC(CSkinnerDlg)

 public:
	CSkinnerDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSkinnerDlg();

	void Localize();
	void SetSkinFilePath(const CString& strPath, bool bRefresh = true);

	CPreferencesDlg* prefswnd;

// Dialog Data
	enum { IDD = IDD_SKINNERDLG };

 protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	afx_msg void OnClose();
	afx_msg void OnSelChange_Section();
	afx_msg void OnSelChange_Groups();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg LRESULT OnColorPopupEndOK(WPARAM wParam, LPARAM lParam);

	void OpenSaveDlg();
	void OpenLoadDlg();
	void OpenPrefsDlg();
	void ShowAbout();

	void ShowColorDlg(const CString& strEntry, CPoint* pPt = NULL);
	void ShowIconDlg(const CString& strEntry);
	void ShowFileDlg(const CString& strEntry, bool bImage = true);
	void ShowDialog(CPoint* pPt = NULL);

	void PreviewSkin(bool bPreview = true);
	void ChangeEntry(const CString& strEntry, const CString& strVal);
	void Undo();
	void Redo();

	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);

 private:
	CSkin m_hSkin;
	CSkin m_bakSkin;
	CString m_strSkinPath;
	bool m_bPreviewing;
	CString m_strLastColorEntry;
	CStringList m_aUndo;
	CStringList m_aRedo;

	CSkinnerToolBarCtrl toolbar;
	CSkinnerListCtrl entrylistctrl;
	CComboBox sectionslist;
	CComboBox groupslist;
};
