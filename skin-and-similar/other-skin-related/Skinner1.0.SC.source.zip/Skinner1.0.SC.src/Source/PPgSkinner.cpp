//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "Skinner.h"
#include "SkinnerDlg.h"
#include "PPgSkinner.h"
#include "Preferences.h"
#include "PrefsDlg.h"
#include "Lang.h"
#include "LangSelect.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


IMPLEMENT_DYNAMIC(CPPgSkinner, CPropertyPage)

BEGIN_MESSAGE_MAP(CPPgSkinner, CPropertyPage)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_TREEOPTSCTRL_NOTIFY, OnTreeOptsCtrlNotify)
END_MESSAGE_MAP()

CPPgSkinner::CPPgSkinner()
	: CPropertyPage(CPPgSkinner::IDD)
	, m_ctrlTreeOptions(ILC_COLOR32)
{
	m_bLangUpdated = false;
	m_iLangIndex = 0;
	theLang.GetAvailableLangs(m_langs);
	for (int i = 0; i < m_langs.GetSize(); i++)
	{
		if (m_langs[i].lid == theLang.GetLang())
		{
			m_iLangIndex = i;
			break;
		}
	}
	m_sLangName = theLang.GetLangLocalName(m_langs[m_iLangIndex].lid);
	m_bConfirmExit = false;
	m_sMulePath = _T(""); // FindMulePath(); //@ functions.h
	m_bUseNetConns = false;
	m_bCheck4Update = true;
	m_sSkinName = _T("");
	m_sSkinProfile = _T("");
	m_sSkinProfileDir = _T("");
	m_bSkinProfileLoaded = false;
	m_bSkinProfileSaved = false;
	for (int k = 0; k < _aModsSize; k++)
	{
		m_abMods[k] = false;
	}

	m_bInitializedTreeOpts = false;
	TreeItemsToNull();
}

CPPgSkinner::~CPPgSkinner()
{
}

void CPPgSkinner::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EXT_OPTS, m_ctrlTreeOptions);
	if (!m_bInitializedTreeOpts)
	{
		int iImgHebmule = 8;
		int iImgLang = 8;
		int iImgSkinProfile = 8;
		int iImgNetConns = 8;
		CImageList* piml = m_ctrlTreeOptions.GetImageList(TVSIL_NORMAL);
		if (piml)
		{
			iImgHebmule = piml->Add(CTempIconLoader(_T("hebMule")));
			iImgLang = piml->Add(CTempIconLoader(_T("Search_Multilingual")));
			iImgSkinProfile = piml->Add(CTempIconLoader(_T("aaaSkinnerApp")));
			iImgNetConns = piml->Add(CTempIconLoader(_T("Internet")));
		}

		m_htiLang = m_ctrlTreeOptions.InsertItem(GetResString(IDS_SKINNERLANG), iImgLang, iImgLang, TVI_ROOT);
		m_ctrlTreeOptions.AddOpaque(m_htiLang, RUNTIME_CLASS(CTreeOptionsLangCombo), RUNTIME_CLASS(CTreeOptionsLangButton), 0);

		m_htiConfirmExit = m_ctrlTreeOptions.InsertCheckBox(GetResString(IDS_PROMPTONEXIT), TVI_ROOT, m_bConfirmExit);
		m_htiMulePath = m_ctrlTreeOptions.InsertItem(GetResString(IDS_EMULEPATH), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, TVI_ROOT);
		m_ctrlTreeOptions.AddFileEditBox(m_htiMulePath, RUNTIME_CLASS(CTreeOptionsEdit), RUNTIME_CLASS(CTreeOptionsBrowseButton));

		m_htiNetConnsPrefs = m_ctrlTreeOptions.InsertGroup(GetResString(IDS_NETCONNSPREFS), iImgNetConns, TVI_ROOT);
		m_htiUseNetConns = m_ctrlTreeOptions.InsertCheckBox(GetResString(IDS_USENETCONNECTIONS), m_htiNetConnsPrefs, m_bUseNetConns);
		m_htiCheck4Update = m_ctrlTreeOptions.InsertCheckBox(GetResString(IDS_CHECKFORUPDATE), m_htiNetConnsPrefs, m_bCheck4Update);

		m_htiSkinProfilePrefs = m_ctrlTreeOptions.InsertGroup(GetResString(IDS_SKINPROFILEPREFS), iImgSkinProfile, TVI_ROOT);
		m_htiSkinName = m_ctrlTreeOptions.InsertItem(GetResString(IDS_SKINNAME), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiSkinProfilePrefs);
		m_ctrlTreeOptions.AddEditBox(m_htiSkinName, RUNTIME_CLASS(CTreeOptionsEdit));
		m_htiSkinProfile = m_ctrlTreeOptions.InsertItem(GetResString(IDS_SKINPROFILE), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiSkinProfilePrefs);
		m_ctrlTreeOptions.AddFileEditBox(m_htiSkinProfile, RUNTIME_CLASS(CTreeOptionsEdit), RUNTIME_CLASS(CTreeOptionsBrowseButton));
		m_htiSkinProfileDir = m_ctrlTreeOptions.InsertItem(GetResString(IDS_SKINPROFILEDIR), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiSkinProfilePrefs);
		m_ctrlTreeOptions.AddFolderEditBox(m_htiSkinProfileDir, RUNTIME_CLASS(CTreeOptionsEdit), RUNTIME_CLASS(CTreeOptionsBrowseButton));
		m_htiSkinProfileLoaded = m_ctrlTreeOptions.InsertCheckBox(GetResString(IDS_SKINPROFILELOADED), m_htiSkinProfilePrefs, m_bSkinProfileLoaded);
		m_htiSkinProfileSaved = m_ctrlTreeOptions.InsertCheckBox(GetResString(IDS_SKINPROFILESAVED), m_htiSkinProfilePrefs, m_bSkinProfileSaved);

		m_htiModCompatPrefs = m_ctrlTreeOptions.InsertGroup(GetResString(IDS_COMPATIBLEMODS), iImgHebmule, TVI_ROOT);
		for (int k = 1; k < _aModsSize; k++)
			m_ahtiMods[k] = m_ctrlTreeOptions.InsertCheckBox(_aMods[k].pszName, m_htiModCompatPrefs, m_abMods[k]);

		if (thePrefs.usenetconns)
			m_ctrlTreeOptions.Expand(m_htiNetConnsPrefs, TVE_EXPAND);
		if (thePrefs.compatiblemods)
			m_ctrlTreeOptions.Expand(m_htiModCompatPrefs, TVE_EXPAND);
		if (thePrefs.SkinProfileSettings())
			m_ctrlTreeOptions.Expand(m_htiSkinProfilePrefs, TVE_EXPAND);

		m_ctrlTreeOptions.SendMessage(WM_VSCROLL, SB_TOP);

		m_bInitializedTreeOpts = true;
	}
	DDX_TreeCombo(pDX, IDC_EXT_OPTS, m_htiLang, m_sLangName);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiConfirmExit, m_bConfirmExit);
	DDX_TreeFileEdit(pDX, IDC_EXT_OPTS, m_htiMulePath, m_sMulePath);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiUseNetConns, m_bUseNetConns);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCheck4Update, m_bCheck4Update);
	DDX_Text(pDX, IDC_EXT_OPTS, m_htiSkinName, m_sSkinName);
	DDX_TreeFileEdit(pDX, IDC_EXT_OPTS, m_htiSkinProfile, m_sSkinProfile);
	DDX_TreeFolderEdit(pDX, IDC_EXT_OPTS, m_htiSkinProfileDir, m_sSkinProfileDir);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiSkinProfileLoaded, m_bSkinProfileLoaded);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiSkinProfileSaved, m_bSkinProfileSaved);
	for (int k = 1; k < _aModsSize; k++)
		DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_ahtiMods[k], m_abMods[k]);
}

BOOL CPPgSkinner::OnInitDialog()
{
	m_bLangUpdated = false;

	m_bConfirmExit = thePrefs.confirmexit;
	m_sMulePath = thePrefs.strMulePath;
	m_bUseNetConns = thePrefs.usenetconns;
	m_bCheck4Update = thePrefs.check4update;
	m_sSkinName = thePrefs.GetSkinName();
	m_sSkinProfile = thePrefs.skinprofile;
	m_sSkinProfileDir = thePrefs.skinprofiledir;
	m_bSkinProfileLoaded = thePrefs.skinprofile_loaded;
	m_bSkinProfileSaved = thePrefs.skinprofile_saved;
	for (int k = 1; k < _aModsSize; k++)
		m_abMods[k] = thePrefs.IsModCompatible(_aMods[k].uID);

	Localize();

	return CPropertyPage::OnInitDialog();
}

BOOL CPPgSkinner::OnKillActive()
{
	// if prop page is closed by pressing VK_ENTER we have to explicitly commit any possibly pending
	// data from an open edit control
	m_ctrlTreeOptions.HandleChildControlLosingFocus();
	return CPropertyPage::OnKillActive();
}

BOOL CPPgSkinner::OnApply()
{
	// if prop page is closed by pressing VK_ENTER we have to explicitly commit any possibly pending
	// data from an open edit control
	m_ctrlTreeOptions.HandleChildControlLosingFocus();

	if (!UpdateData())
		return FALSE;

	thePrefs.confirmexit = m_bConfirmExit;
	if (!m_sMulePath.Right(4).CompareNoCase(_T(".exe")))
		thePrefs.strMulePath = m_sMulePath;
	thePrefs.usenetconns = m_bUseNetConns;
	thePrefs.check4update = m_bCheck4Update;
	thePrefs.skinname = m_sSkinName;
	thePrefs.SetSkinProfile(m_sSkinProfile);
	thePrefs.SetSkinProfileDir(m_sSkinProfileDir);
	thePrefs.skinprofile_loaded = m_bSkinProfileLoaded;
	thePrefs.skinprofile_saved = m_bSkinProfileSaved;

	bool bModChange = false;
	for (int k = 1; k < _aModsSize; k++)
	{
		bModChange |= (thePrefs.IsModCompatible(_aMods[k].uID) != m_abMods[k]);
		thePrefs.SetModCompatible(_aMods[k].uID, m_abMods[k]);
	}

	if (m_langs[m_iLangIndex].lid != theLang.GetLang() || m_bLangUpdated)
	{
		theLang.SetLang(m_langs[m_iLangIndex].lid);
		Localize();
		theApp.skinnerdlg->Localize();
		theApp.skinnerdlg->prefswnd->Localize();
	}
	if (bModChange)
		theApp.skinnerdlg->Localize();

	SetModified(FALSE);
	return CPropertyPage::OnApply();
}

void CPPgSkinner::OnDestroy()
{
	m_ctrlTreeOptions.DeleteAllItems();
	m_ctrlTreeOptions.DestroyWindow();
	m_bInitializedTreeOpts = false;

	TreeItemsToNull();

	CPropertyPage::OnDestroy();
}

LRESULT CPPgSkinner::OnTreeOptsCtrlNotify(WPARAM wParam, LPARAM lParam)
{
	if (wParam == IDC_EXT_OPTS)
	{
		TREEOPTSCTRLNOTIFY* pton = (TREEOPTSCTRLNOTIFY*)lParam;
		if (m_htiLang && pton->hItem == m_htiLang)
		{
			CTreeOptionsLangCombo* langcombo = (CTreeOptionsLangCombo*)pton->nmhdr.code;
			CTreeOptionsLangButton* langbutton = (CTreeOptionsLangButton*)pton->nmhdr.code;
			if (langcombo && langcombo->IsKindOf(RUNTIME_CLASS(CTreeOptionsLangCombo)))
			{
				m_iLangIndex = langcombo->GetCurSel();
				if (m_iLangIndex && !m_langs[m_iLangIndex].bSupported && thePrefs.usenetconns &&
					AfxMessageBox(GetResString(IDS_DOWNLOADLANG), MB_OKCANCEL) == IDOK)
					m_bLangUpdated |= theLang.DownloadLang(m_langs[m_iLangIndex].lid);
			}
			else if (langbutton && langbutton->IsKindOf(RUNTIME_CLASS(CTreeOptionsLangButton)))
				m_bLangUpdated |= theLang.DownloadLang(m_langs[m_iLangIndex].lid);

			if (m_bLangUpdated)
				theLang.GetAvailableLangs(m_langs);
		}
		if (m_htiUseNetConns && pton->hItem == m_htiUseNetConns)
		{
			BOOL bCheck;
			if (m_ctrlTreeOptions.GetCheckBox(m_htiUseNetConns, bCheck))
				m_ctrlTreeOptions.SetCheckBoxEnable(m_htiCheck4Update, bCheck);
		}
		SetModified();
	}
	return 0;
}

void CPPgSkinner::Localize()
{
	if (!m_hWnd)
		return;

	SetWindowText(GetResString(IDS_SKINNERPREFS));
	SetDlgItemText(IDC_PREFSWARNING, GetResString(IDS_PREFSWARNING));

	if (m_htiLang)
	{
		m_ctrlTreeOptions.SetEditLabel(m_htiLang, GetResString(IDS_SKINNERLANG));
		m_ctrlTreeOptions.SetComboText(m_htiLang, m_sLangName);
	}
	if (m_htiConfirmExit) m_ctrlTreeOptions.SetItemText(m_htiConfirmExit, GetResString(IDS_PROMPTONEXIT));
	if (m_htiMulePath) m_ctrlTreeOptions.SetEditLabel(m_htiMulePath, GetResString(IDS_EMULEPATH));
	if (m_htiNetConnsPrefs) m_ctrlTreeOptions.SetEditLabel(m_htiNetConnsPrefs, GetResString(IDS_NETCONNSPREFS));
	if (m_htiUseNetConns) m_ctrlTreeOptions.SetItemText(m_htiUseNetConns, GetResString(IDS_USENETCONNECTIONS));
	if (m_htiCheck4Update) m_ctrlTreeOptions.SetItemText(m_htiCheck4Update, GetResString(IDS_CHECKFORUPDATE));
	if (m_htiSkinProfilePrefs) m_ctrlTreeOptions.SetEditLabel(m_htiSkinProfilePrefs, GetResString(IDS_SKINPROFILEPREFS));
	if (m_htiSkinName) m_ctrlTreeOptions.SetEditLabel(m_htiSkinName, GetResString(IDS_SKINNAME));
	if (m_htiSkinProfile) m_ctrlTreeOptions.SetEditLabel(m_htiSkinProfile, GetResString(IDS_SKINPROFILE));
	if (m_htiSkinProfileDir) m_ctrlTreeOptions.SetEditLabel(m_htiSkinProfileDir, GetResString(IDS_SKINPROFILEDIR));
	if (m_htiSkinProfilePrefs) m_ctrlTreeOptions.SetEditLabel(m_htiSkinProfilePrefs, GetResString(IDS_SKINPROFILEPREFS));
	if (m_htiSkinProfileLoaded) m_ctrlTreeOptions.SetItemText(m_htiSkinProfileLoaded, GetResString(IDS_SKINPROFILELOADED));
	if (m_htiSkinProfileSaved) m_ctrlTreeOptions.SetItemText(m_htiSkinProfileSaved, GetResString(IDS_SKINPROFILESAVED));
	if (m_htiModCompatPrefs) m_ctrlTreeOptions.SetEditLabel(m_htiModCompatPrefs, GetResString(IDS_COMPATIBLEMODS));
}

void CPPgSkinner::TreeItemsToNull()
{
	m_htiLang = NULL;
	m_htiConfirmExit = NULL;
	m_htiMulePath = NULL;
	m_htiNetConnsPrefs = NULL;
	m_htiUseNetConns = NULL;
	m_htiCheck4Update = NULL;
	m_htiSkinProfilePrefs = NULL;
	m_htiSkinName = NULL;
	m_htiSkinProfile = NULL;
	m_htiSkinProfileDir = NULL;
	m_htiSkinProfileLoaded = NULL;
	m_htiSkinProfileSaved = NULL;
	m_htiModCompatPrefs = NULL;
	for (int k = 0; k < _aModsSize; k++)
	{
		m_ahtiMods[k] = NULL;
	}
}
