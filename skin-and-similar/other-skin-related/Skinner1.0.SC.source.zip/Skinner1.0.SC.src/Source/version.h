//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#ifndef __VERSION_H__
#define __VERSION_H__

#pragma once

#ifndef _T
#define _T(x)	x
#endif
#define _chSTR(x)		_T(#x)
#define chSTR(x)		_chSTR(x)

// this version format is similar to eMule version format

#define SKINNER_VERMJR		1
#define SKINNER_VERMIN		0
#define SKINNER_VERUPDATE	0

#define SKINNER_VERSTR		chSTR(SKINNER_VERMJR) _T(".") chSTR(SKINNER_VERMIN) _T(".") chSTR(SKINNER_VERUPDATE)

#endif
