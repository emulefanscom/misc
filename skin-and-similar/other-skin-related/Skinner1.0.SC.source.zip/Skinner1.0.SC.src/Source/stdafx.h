//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#endif

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef WINVER				// Allow use of features specific to Windows 95 and Windows NT 4 or later.
#define WINVER 0x0400		// Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#endif

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows NT 4 or later.
#define _WIN32_WINNT 0x0400		// Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#endif						

#ifndef _WIN32_WINDOWS		// Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0410 // Change this to the appropriate value to target Windows Me or later.
#endif

#ifndef _WIN32_IE			// Allow use of features specific to IE 4.0 or later.
#define _WIN32_IE 0x0400	// Change this to the appropriate value to target IE 5.0 or later.
#endif

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit

// turns off MFC's hiding of some common and often safely ignored warning messages
#define _AFX_ALL_WARNINGS

#define _CRT_NON_CONFORMING_SWPRINTFS

#include <afxwin.h>	// MFC core and standard components
#include <afxext.h>	// MFC extensions
#include <afxtempl.h>	// MFC template classes
#include <afxdlgs.h>	// MFC Standard dialogs
#include <afxinet.h>	// MFC Internet classes
#include <afxdtctl.h>	// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>	// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT
#include <afxdhtml.h>
#include <atlimage.h>	// MFC/ATL CImage class

#include "types.h"
#include "version.h"
#include "UserMsgsCmds.h"
#include "SkinGroups.h"

#define MAX_STRLEN		512
#define MAX_STRLEN2		1024
#define ARRSIZE(x)	(sizeof(x)/sizeof(x[0]))
#if _MSC_VER<=1310
#define _countof(x)		ARRSIZE(x)
#endif


//TODO: To be removed and properly resolved in the sources...
#pragma warning(disable:4267) // 
#pragma warning(disable:4244) // conversion from 'type1' to 'type2', possible loss of data
#pragma warning(disable:4800) // 'type' : forcing value to bool 'true' or 'false' (performance warning)
#pragma warning(disable:4805) // unsafe mix of type 'bool' and type 'int' in operation
#pragma warning(disable:4389) // signed/unsigned mismatch
#pragma warning(disable:4311) // pointer truncation from 'type1*' to 'type2'
#pragma warning(disable:4312) // conversion from 'type1' to 'type2' of greater size
#pragma warning(disable:4100) // unreferenced formal parameter
#pragma warning(disable:4819) // The file contains a character that cannot be represented...

