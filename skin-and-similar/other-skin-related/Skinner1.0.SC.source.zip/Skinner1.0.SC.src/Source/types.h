//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#ifndef __TYPES_H__
#define __TYPES_H__

#pragma once

// regular types
typedef unsigned char	uint8, uchar;
typedef signed char		sint8;

typedef unsigned short	uint16;
typedef signed short	sint16;

typedef unsigned int	uint32;
typedef signed int		sint32;

typedef unsigned __int64	uint64;
typedef signed __int64	sint64;

#endif
