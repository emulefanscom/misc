//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "Skinner.h"
#include "Skin.h"
#include "SkinnerDlg.h"
#include "Preferences.h"
#include "Lang.h"
#include "functions.h"
#include "mdump.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


const UINT CSkinnerApp::m_uSkinnerID = RegisterWindowMessage(_T("eMuleSkinner[Avi3k][hebMule.sf.net]\0")); // --> Note: Do not change this part - Avi3k

CSkinnerApp::CSkinnerApp(LPCTSTR lpszAppName)
	: CWinApp(lpszAppName)
{
	// --> Note: Do not change this part - Avi3k
	m_strVersion.Format(_T("%u.%u"), SKINNER_VERMJR, SKINNER_VERMIN);
	if (SKINNER_VERUPDATE)
		m_strVersion.AppendFormat(_T("%c"), _T('a')+SKINNER_VERUPDATE);
	defSkin.SetAt(_T("Skinfo_App"), _T("Skinner") + m_strVersion);
	// <-- end note

	TCHAR szUser[MAX_STRLEN] = {0};
	DWORD dwSize = ARRSIZE(szUser);
	if (GetUserName(szUser, &dwSize) && dwSize > 0)
		defSkin.SetAt(_T("Skinfo_Author"), szUser);

	m_hMods = LoadLibrary(_T("eMuleMods.dll"));
}

CSkinnerApp::~CSkinnerApp()
{
	if (m_hMods)
		FreeLibrary(m_hMods);
}

BEGIN_MESSAGE_MAP(CSkinnerApp, CWinApp)
	ON_COMMAND(ID_HELP, OnHelp)
END_MESSAGE_MAP()

CSkinnerApp theApp(_T("Skinner")); // --> Note: Do not change this part - Avi3k


#ifdef _DEBUG
static CMemoryState oldMemState, newMemState;
#endif

BOOL CSkinnerApp::InitInstance()
{
#ifdef _DEBUG
	oldMemState.Checkpoint();
#endif

	if (GetProfileInt(_T("Skinner"), _T("CreateCrashDump"), 0))
		CMiniDumper::Enable(_T("Skinner ") + m_strVersion, true);

	AfxOleInit();

	if (ProcessCmdLine())
		return FALSE;

	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	thePrefs.Init();

	CSkinnerDlg dlg;
	skinnerdlg = &dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

#ifdef _DEBUG
	CMemoryState diffMemState;
	newMemState.Checkpoint();
	if (diffMemState.Difference(oldMemState, newMemState))
	{
		TRACE("Memory usage:\n");
		diffMemState.DumpStatistics();
	}
#endif

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}


void CSkinnerApp::OnHelp()
{
	ShowHelp();
}

void CSkinnerApp::ShowHelp(LPCTSTR morehelp)
{
	// --> Note: Do not change this part - Avi3k
	CString buffer;
	buffer.Format(_T("http://hebmule.sourceforge.net/?lang=%s&page=skinner"), theLang.GetLangCode(theLang.GetLang()));
	if (morehelp)
		buffer.AppendFormat(_T("%s"), morehelp);
	ShellExecute(NULL, _T("open"), buffer, NULL, NULL, SW_SHOW);
	// <-- end note
}

bool CSkinnerApp::ProcessCmdLine()
{
	HWND maininst = NULL;
	EnumWindows(SearchSkinnerWindow, (LPARAM)&maininst);
	if (__argc == 2 && IsSkinFile(__targv[1]))
	{
		CString strSkin = CString(__targv[1]).Trim();
		if (IsArchiveFile(strSkin) && !ExtractSkin(strSkin, true))
			return false;
		if (strSkin.IsEmpty() || !PathFileExists(strSkin))
			return false;
		if (maininst)
		{
			SendMessage(maininst, WM_COMMAND, MP_SETSKINFILE, (LPARAM)(LPCTSTR)strSkin);
			return true;
		}
		else
			m_strPendingCmd.Format(_T("%u::%s"), MP_SETSKINFILE, strSkin);
	}
	return (maininst != NULL);
}

BOOL CALLBACK CSkinnerApp::SearchSkinnerWindow(HWND hWnd, LPARAM lParam) // from eMule (modified)
{
	DWORD dwMsgResult;
	LRESULT res = ::SendMessageTimeout(hWnd, m_uSkinnerID, 0, 0, SMTO_BLOCK | SMTO_ABORTIFHUNG, 10000, &dwMsgResult);
	if (res == 0 || dwMsgResult != m_uSkinnerID)
		return TRUE;
	HWND* target = (HWND*)lParam;
	*target = hWnd;
	return FALSE;
}

bool CSkinnerApp::CopyTextToClipboard(const CString& strText) // from eMule
{
	if (strText.IsEmpty())
		return false;

	HGLOBAL hGlobalT = GlobalAlloc(GHND | GMEM_SHARE, (strText.GetLength() + 1) * sizeof(TCHAR));
	if (hGlobalT != NULL)
	{
		LPTSTR pGlobalT = static_cast<LPTSTR>(GlobalLock(hGlobalT));
		if (pGlobalT != NULL)
		{
			_tcscpy(pGlobalT, strText);
			GlobalUnlock(hGlobalT);
		}
		else
		{
			GlobalFree(hGlobalT);
			hGlobalT = NULL;
		}
	}

	CStringA strTextA(strText);
	HGLOBAL hGlobalA = GlobalAlloc(GHND | GMEM_SHARE, (strTextA.GetLength() + 1) * sizeof(CHAR));
	if (hGlobalA != NULL)
	{
		LPSTR pGlobalA = static_cast<LPSTR>(GlobalLock(hGlobalA));
		if (pGlobalA != NULL)
		{
			strcpy(pGlobalA, strTextA);
			GlobalUnlock(hGlobalA);
		}
		else
		{
			GlobalFree(hGlobalA);
			hGlobalA = NULL;
		}
	}

	if (hGlobalT == NULL && hGlobalA == NULL)
		return false;

	int iCopied = 0;
	if (OpenClipboard(NULL))
	{
		if (EmptyClipboard())
		{
			if (hGlobalT){
				if (SetClipboardData(CF_UNICODETEXT, hGlobalT) != NULL){
					iCopied++;
				}
				else{
					GlobalFree(hGlobalT);
					hGlobalT = NULL;
				}
			}
			if (hGlobalA){
				if (SetClipboardData(CF_TEXT, hGlobalA) != NULL){
					iCopied++;
				}
				else{
					GlobalFree(hGlobalA);
					hGlobalA = NULL;
				}
			}
		}
		CloseClipboard();
	}

	if (iCopied == 0)
	{
		if (hGlobalT){
			GlobalFree(hGlobalT);
			hGlobalT = NULL;
		}
		if (hGlobalA){
			GlobalFree(hGlobalA);
			hGlobalA = NULL;
		}
	}

	return (iCopied != 0);
}

CString CSkinnerApp::CopyTextFromClipboard() // from eMule
{
	if (IsClipboardFormatAvailable(CF_UNICODETEXT))
	{
		if (OpenClipboard(NULL))
		{
			bool bResult = false;
			CString strClipboard;
			HGLOBAL hMem = GetClipboardData(CF_UNICODETEXT);
			if (hMem)
			{
				LPCWSTR pwsz = (LPCWSTR)GlobalLock(hMem);
				if (pwsz)
				{
					strClipboard = pwsz;
					GlobalUnlock(hMem);
					bResult = true;
				}
			}
			CloseClipboard();
			if (bResult)
				return strClipboard;
		}
	}

	if (!IsClipboardFormatAvailable(CF_TEXT))
		return _T("");
	if (!OpenClipboard(NULL))
		return _T("");

	CString	retstring;
	HGLOBAL	hglb = GetClipboardData(CF_TEXT);
	if (hglb != NULL)
	{
		LPCSTR lptstr = (LPCSTR)GlobalLock(hglb);
		if (lptstr != NULL)
		{
			retstring = lptstr;
			GlobalUnlock(hglb);
		}
	}
	CloseClipboard();

	return retstring;
}


// from eMule
CTempIconLoader::CTempIconLoader(LPCTSTR pszResourceID, int cx, int cy, UINT uFlags)
{
	m_hIcon = LoadIcon(pszResourceID, cx, cy, uFlags);
}

CTempIconLoader::~CTempIconLoader()
{
	if (m_hIcon)
		VERIFY( DestroyIcon(m_hIcon) );
}

HICON CTempIconLoader::LoadIcon(LPCTSTR lpszResourceName, int cx, int cy, UINT uFlags) const
{
	HICON hIcon = NULL;
	LPCTSTR pszSkinProfile = thePrefs.GetSkinProfile();
	if (pszSkinProfile != NULL && pszSkinProfile[0] != _T('\0'))
	{
		// load icon resource file specification from skin profile
		TCHAR szSkinResource[MAX_PATH];
		GetPrivateProfileString(_T("Icons"), lpszResourceName, _T(""), szSkinResource, ARRSIZE(szSkinResource), pszSkinProfile);
		if (szSkinResource[0] != _T('\0'))
		{
			// expand any optional available environment strings
			TCHAR szExpSkinRes[MAX_PATH];
			if (ExpandEnvironmentStrings(szSkinResource, szExpSkinRes, ARRSIZE(szExpSkinRes)) != 0)
			{
				_tcsncpy(szSkinResource, szExpSkinRes, ARRSIZE(szSkinResource));
				szSkinResource[ARRSIZE(szSkinResource)-1] = _T('\0');
			}

			// create absolute path to icon resource file
			TCHAR szFullResPath[MAX_PATH];
			if (PathIsRelative(szSkinResource))
			{
				TCHAR szSkinResFolder[MAX_PATH];
				_tcsncpy(szSkinResFolder, pszSkinProfile, ARRSIZE(szSkinResFolder));
				szSkinResFolder[ARRSIZE(szSkinResFolder)-1] = _T('\0');
				PathRemoveFileSpec(szSkinResFolder);
				_tmakepath(szFullResPath, NULL, szSkinResFolder, szSkinResource, NULL);
			}
			else
			{
				_tcsncpy(szFullResPath, szSkinResource, ARRSIZE(szFullResPath));
				szFullResPath[ARRSIZE(szFullResPath)-1] = _T('\0');
			}

			// check for optional icon index or resource identifier within the icon resource file
			bool bExtractIcon = false;
			CString strFullResPath = szFullResPath;
			int iIconIndex = 0;
			int iComma = strFullResPath.ReverseFind(_T(','));
			if (iComma != -1){
				if (_stscanf((LPCTSTR)strFullResPath + iComma + 1, _T("%d"), &iIconIndex) == 1)
					bExtractIcon = true;
				strFullResPath = strFullResPath.Left(iComma);
			}

			if (bExtractIcon)
			{
				HICON aIconsLarge[1] = {0};
				HICON aIconsSmall[1] = {0};
				int iExtractedIcons = ExtractIconEx(strFullResPath, iIconIndex, aIconsLarge, aIconsSmall, 1);
				if (iExtractedIcons > 0) // 'iExtractedIcons' is 2(!) if we get a large and a small icon
				{
					// alway try to return the icon size which was requested
					if ((cx <= 16 || aIconsLarge[0] == NULL) && aIconsSmall[0] != NULL)
					{
						hIcon = aIconsSmall[0];
						aIconsSmall[0] = NULL;
					}
					if (hIcon == NULL && aIconsLarge[0] != NULL)
					{
						hIcon = aIconsLarge[0];
						aIconsLarge[0] = NULL;
					}

					for (int i = 0; i < ARRSIZE(aIconsLarge); i++)
					{
						if (aIconsLarge[i] != NULL)
							VERIFY( DestroyIcon(aIconsLarge[i]) );
						if (aIconsSmall[i] != NULL)
							VERIFY( DestroyIcon(aIconsSmall[i]) );
					}
				}
			}
			else
			{
				// WINBUG???: 'ExtractIcon' does not work well on ICO-files when using the color 
				// scheme 'Windows-Standard (extragro)' -> always try to use 'LoadImage'!
				//
				// If the ICO file contains a 16x16 icon, 'LoadImage' will though return a 32x32 icon,
				// if LR_DEFAULTSIZE is specified! -> always specify the requested size!
				hIcon = (HICON)::LoadImage(NULL, szFullResPath, IMAGE_ICON, cx, cy, uFlags | LR_LOADFROMFILE);
			}
		}
	}

	if (hIcon == NULL)
	{
		if (cx != LR_DEFAULTSIZE || cy != LR_DEFAULTSIZE || uFlags != LR_DEFAULTCOLOR)
			hIcon = (HICON)::LoadImage(AfxGetResourceHandle(), lpszResourceName, IMAGE_ICON, cx, cy, uFlags);
		if (hIcon == NULL)
			hIcon = theApp.LoadIcon(lpszResourceName);

		if (hIcon == NULL && theApp.m_hMods != NULL)
			hIcon = (HICON)::LoadImage(theApp.m_hMods, lpszResourceName, IMAGE_ICON, cx, cy, uFlags);
	}
	return hIcon;
}

