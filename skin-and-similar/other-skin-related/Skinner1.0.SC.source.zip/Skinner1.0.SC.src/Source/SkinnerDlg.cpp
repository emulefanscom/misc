//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "SkinnerDlg.h"
#include "Skinner.h"
#include "Skin.h"
#include "Lang.h"
#include "functions.h"
#include "SkinnerListCtrl.h"
#include "SkinnerToolBarCtrl.h"
#include "Preferences.h"
#include "PrefsDlg.h"
#include "IconDlg.h"
#include "ColourPopup.h"

#define SAVESKIN_FLAGS (OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_CREATEPROMPT)
#define LOADSKIN_FLAGS (OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST)


IMPLEMENT_DYNAMIC(CSkinnerDlg, CDialog)
CSkinnerDlg::CSkinnerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSkinnerDlg::IDD, pParent)
{
	prefswnd = new CPreferencesDlg;
	m_hSkin = m_bakSkin = theApp.defSkin;
	m_bPreviewing = false;
	m_strLastColorEntry = _T("");
}

CSkinnerDlg::~CSkinnerDlg()
{
	if (prefswnd)
		delete prefswnd;
	prefswnd = NULL;
}

void CSkinnerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MAINTOOLBAR, toolbar);
	DDX_Control(pDX, IDC_ENTRYLIST, entrylistctrl);
	DDX_Control(pDX, IDC_SECTIONS, sectionslist);
	DDX_Control(pDX, IDC_GROUPS, groupslist);
}


BOOL CSkinnerDlg::OnInitDialog()
{
	BOOL bRet = CDialog::OnInitDialog();

	SetWindowText(_T("Skinner v") + theApp.GetVersionStr());
	SetIcon(CTempIconLoader(_T("aaaSkinnerApp")), true);

	this->DragAcceptFiles(TRUE);
	toolbar.InitToolbar();
	entrylistctrl.InitListCtrl();

	if (!thePrefs.skinprofile.IsEmpty())
		SetSkinFilePath(thePrefs.skinprofile, false);
	if (!theApp.m_strPendingCmd.IsEmpty())
	{
		UINT nCmd = 0;
		TCHAR szBuff[MAX_PATH] = {0};
		if (_stscanf(theApp.m_strPendingCmd, _T("%u::%s"), &nCmd, szBuff) == 2)
			SendMessage(WM_COMMAND, (WPARAM)nCmd, (LPARAM)szBuff);
		theApp.m_strPendingCmd = _T("");
	}

	Localize();

	SendMessage(WM_COMMAND, MP_UPDATE_TBBTNS);

	return bRet;
}


BEGIN_MESSAGE_MAP(CSkinnerDlg, CDialog)
	ON_CBN_SELCHANGE(IDC_SECTIONS, OnSelChange_Section)
	ON_CBN_SELCHANGE(IDC_GROUPS, OnSelChange_Groups)
	ON_CBN_SETFOCUS(IDC_SECTIONS, OnSelChange_Section)
	ON_CBN_SETFOCUS(IDC_GROUPS, OnSelChange_Groups)
	ON_WM_CLOSE()
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_WM_DROPFILES()
	ON_MESSAGE(UM_CPN_SELENDOK, OnColorPopupEndOK)
	//ON_MESSAGE(UM_CPN_SELCHANGE, OnColorPopupEndOK)
END_MESSAGE_MAP()


void CSkinnerDlg::OnClose()
{
	if (thePrefs.confirmexit && AfxMessageBox(GetResString(IDS_CONFIRMEXIT), MB_YESNO) == IDNO)
		return;

	if (!m_strSkinPath.IsEmpty())
		m_bakSkin.Save(m_strSkinPath);

	thePrefs.Uninit();

	CDialog::OnCancel();
}


void CSkinnerDlg::Localize()
{
	SetDlgItemText(IDC_STATIC_SECTION, GetResString(IDS_SECTION)+_T(":"));
	toolbar.Localize();

	sectionslist.ResetContent();
	for (int i = 0; i < ARRSIZE(_skinInfo) && _skinInfo[i].pszName; i++)
	{
		int idx = sectionslist.AddString(theLang.GetString(_skinInfo[i].pszName));
		sectionslist.SetItemData(idx, (DWORD_PTR)(skinSection*)(_skinInfo+i));
	}
	sectionslist.SetCurSel(0);

	OnSelChange_Section(); //calls OnSelChange_Groups();

	entrylistctrl.Localize();
}

void CSkinnerDlg::OnSelChange_Section()
{
	groupslist.ResetContent();
	entrylistctrl.DeleteAllItems();

	int iCurSel = (int)sectionslist.GetCurSel();
	skinSection* pSection = (iCurSel >= 0) ? (skinSection*)sectionslist.GetItemData(iCurSel) : NULL;
	if (!pSection || !pSection->aGroups)
		return;

	entrylistctrl.SetValueType(pSection->pszName);
	entrylistctrl.Localize();

	for (const skinGroup* pGrps = pSection->aGroups; pGrps && pGrps->pszName; pGrps++)
	{
		bool bAdd = true;
		CString sName(pGrps->pszName);
		for (int k = 0; k < ARRSIZE(_aMods) && bAdd; k++)
			bAdd = bAdd && (thePrefs.IsModCompatible(_aMods[k].uID) || sName.Right(_tcslen(_aMods[k].pszName)).CompareNoCase(_aMods[k].pszName) != 0);
		if (!bAdd)
			continue;
		int idx = groupslist.AddString(theLang.GetString(pGrps->pszName));
		groupslist.SetItemData(idx, (DWORD_PTR)pGrps);
	}
	groupslist.SetCurSel(0);
	OnSelChange_Groups();
}

void CSkinnerDlg::OnSelChange_Groups()
{
	entrylistctrl.DeleteAllItems();

	int iCurSel = (int)groupslist.GetCurSel();
	skinGroup* pGrp = (iCurSel >= 0) ? (skinGroup*)groupslist.GetItemData(iCurSel) : NULL;
	if (iCurSel < 0 || !pGrp)
		return;

	COLORREF bg = CLR_DEFAULT, fg = CLR_DEFAULT;
	for (int i = 0; i < ARRSIZE(pGrp->aItems) && pGrp->aItems[i] != NULL; i++)
	{
		CString sEntry(pGrp->aItems[i]), sVal = m_hSkin.GetAt(pGrp->aItems[i]);
		entrylistctrl.InsertItem(sEntry, sVal, (DWORD_PTR)pGrp->aItems[i]);
		if (!sVal.IsEmpty() && !sEntry.Right(2).CompareNoCase(_T("bk")))
			bg = str2color(sVal);
		if (!sVal.IsEmpty() && !sEntry.Right(2).CompareNoCase(_T("fg")))
			fg = str2color(sVal);
	}
	if (fg == CLR_DEFAULT)
		fg = ::GetSysColor(COLOR_WINDOWTEXT);
	if (bg == CLR_DEFAULT)
		bg = ::GetSysColor(COLOR_WINDOW);
	entrylistctrl.SetBkColor(bg);
	entrylistctrl.SetTextBkColor(bg);
	entrylistctrl.SetTextColor(fg);
	Invalidate();
}

void CSkinnerDlg::ShowColorDlg(const CString& strEntry, CPoint* pPt)
{
	m_strLastColorEntry = strEntry;
	COLORREF oldColor = str2color(m_hSkin.GetAt(strEntry));
	CPoint ptPos;

	if (!pPt)
	{
		LVFINDINFO info;
		info.flags = LVFI_STRING;
		info.psz = (LPCTSTR)strEntry;
		entrylistctrl.GetItemPosition(entrylistctrl.FindItem(&info), &ptPos);
	}
	else
	{
		ptPos = *pPt;
	}
	entrylistctrl.ClientToScreen(&ptPos);
	ptPos.Offset(3, 3);

	CColourPopup* pCP = new CColourPopup(ptPos, oldColor, &entrylistctrl, GetResString(IDS_KEEPCURRENT), GetResString(IDS_MORE));
	pCP->SetFocus();
}

void CSkinnerDlg::ShowIconDlg(const CString& strEntry)
{
	CString strFileName = m_hSkin.GetAt(strEntry);
	CString strVal = strFileName;
	int iIconIndex = 0;
	GetIconFileIndex(strFileName, iIconIndex);
	CIconDialog idlg;
	idlg.SetIcon(strFileName, iIconIndex);
	if (idlg.DoModal() != IDOK)
		return;
	idlg.GetIcon(strFileName, iIconIndex);
	if (strFileName.Right(4).CompareNoCase(_T(".ico")))
		strFileName.AppendFormat(_T(",%d"), iIconIndex);
	ChangeEntry(strEntry, strFileName);
	OnSelChange_Groups();
}

void CSkinnerDlg::ShowFileDlg(const CString& strEntry, bool bImage)
{
	CString strFilter, strSkinPath = m_strSkinPath;
	CString strTitle = (bImage) ? GetResString(IDS_SELECTIMAGE) : GetResString(IDS_SELECTHTMLPAGE);
	if (bImage)
		strFilter = GetResString(IDS_COMMONIMAGEFILES) + _T(" (*.bmp, *.png, *.jpg, *.jpeg, *.gif)|*.bmp; *.png; *.jpg; *.jpeg; *.gif|");
	else
		strFilter = GetResString(IDS_HTMLPAGEFILES) + _T(" (*.html, *.htm)|*.html; *.htm|");
	strFilter += GetResString(IDS_ALLFILES) + _T(" (*.*)|*.*||");

	CFileDialog dlg(TRUE, (bImage) ? _T("*.bmp") : _T("*.html"), strSkinPath, LOADSKIN_FLAGS, strFilter, this);
	dlg.m_ofn.lpstrTitle = strTitle;
	if (dlg.DoModal() == IDOK)
	{
		ChangeEntry(strEntry, dlg.GetPathName());
		OnSelChange_Groups();
	}
}

void CSkinnerDlg::ShowDialog(CPoint* pPt)
{
	int iCurSel = entrylistctrl.GetSelectionMark();
	if (iCurSel == -1 || entrylistctrl.GetSelectedCount() != 1)
		return;
	CString strEntry = (LPCTSTR)entrylistctrl.GetItemData(iCurSel);
	int iSecSel = (int)sectionslist.GetCurSel();
	skinSection* pSection = NULL;
	if (iSecSel >= 0)
		pSection = (skinSection*)sectionslist.GetItemData(iSecSel);
	if (!pSection || _tcsicmp(pSection->pszName, _T("skinfo")) == 0)
		return;
	if (_tcsicmp(pSection->pszName, _T("colors")) == 0)
		ShowColorDlg(strEntry, pPt);
	else if (_tcsicmp(pSection->pszName, _T("icons")) == 0)
		ShowIconDlg(strEntry);
	else
		ShowFileDlg(strEntry, _tcsicmp(pSection->pszName, _T("bitmaps")) == 0);
	SendMessage(WM_COMMAND, MP_UPDATE_TBBTNS);
}

void CSkinnerDlg::OpenSaveDlg()
{
	CString strFilter, strSkinPath = m_strSkinPath, strTitle = GetResString(IDS_SAVE);
	if (strSkinPath.IsEmpty())
		strSkinPath = thePrefs.GetSkinFileName(m_hSkin.GetAt(_T("Skinfo_SkinName")));
	strFilter.Format(_T("%s (*.eMuleSkin[.ini])|*.eMuleSkin; *.eMuleSkin.ini||"), GetResString(IDS_SKINFILE));
	CFileDialog dlg(FALSE, _T("*.eMuleSkin.ini"), strSkinPath, SAVESKIN_FLAGS, strFilter, this);
	dlg.m_ofn.lpstrTitle = strTitle;
	if (dlg.DoModal() != IDOK)
		return;
	m_hSkin.Save(dlg.GetPathName());
	if (thePrefs.skinprofile_saved)
		thePrefs.SetSkinProfile(dlg.GetPathName());
	// don't exit anymore... //thePrefs.Uninit();//CDialog::OnOK();
}

void CSkinnerDlg::OpenLoadDlg()
{
	CString strFilter, strSkinPath = m_strSkinPath, strTitle = GetResString(IDS_LOAD);
	if (strSkinPath.IsEmpty())
		strSkinPath = thePrefs.GetSkinProfileDir() + _T("*.eMuleSkin*");
	strFilter.Format(_T("%s (*.eMuleSkin[.ini])|*.eMuleSkin; *.eMuleSkin.ini|%s (*.eMuleSkinZip)|*.eMuleSkinzip; *.eMuleSkin.zip|%s (*.eMuleSkinRar)|*.eMuleSkinrar; *.eMuleSkin.rar||"),
		GetResString(IDS_SKINFILE), GetResString(IDS_SKINFILEZIPPED), GetResString(IDS_SKINFILERARRED));
	CFileDialog dlg(TRUE, _T("*.eMuleSkin*"), strSkinPath, LOADSKIN_FLAGS, strFilter, this);
	dlg.m_ofn.lpstrTitle = strTitle;
	if (dlg.DoModal() != IDOK)
		return;
	strSkinPath = dlg.GetPathName();
	if (IsArchiveFile(strSkinPath) && !ExtractSkin(strSkinPath, true))
		return;
	SetSkinFilePath(strSkinPath);
}

void CSkinnerDlg::SetSkinFilePath(const CString& strPath, bool bRefresh)
{
	m_strSkinPath = strPath;
	m_hSkin.Load(m_strSkinPath);
	m_bakSkin = m_hSkin; // copy for backup
	if (thePrefs.skinprofile_loaded)
		thePrefs.SetSkinProfile(m_strSkinPath);
	m_aUndo.RemoveAll();
	m_aRedo.RemoveAll();
	if (bRefresh)
		OnSelChange_Groups();
}

void CSkinnerDlg::OpenPrefsDlg()
{
	if (prefswnd)
		prefswnd->DoModal();
}

// --> Note: Do not change this function in any way - Avi3k
void CSkinnerDlg::ShowAbout()
{
	TCHAR szBuff[16];
	time_t tNow = time(NULL);
	_tcsftime(szBuff, ARRSIZE(szBuff), _T("%Y"), localtime(&tNow));
	CString strAbout;
	strAbout.Format(_T("Skinner v%s by Avi3k (hebMule@gmail.com)\r\n%s  � 2003-%s\r\n%s"),
		theApp.GetVersionStr(), GetResString(IDS_ALLRIGHTS), szBuff, GetResString(IDS_RELEASEDGPL));
	AfxMessageBox(strAbout);
}
// <-- end note

void CSkinnerDlg::PreviewSkin(bool bPreview)
{
	if (thePrefs.strMulePath.IsEmpty() || thePrefs.strMuleConfigFile.IsEmpty())
		return;
	CString strNewSkin = thePrefs.GetSkinProfileDir() + _T("tmp.emuleskin");
	TCHAR strOrigSkin[MAX_PATH];
	if (bPreview)
	{
		GetPrivateProfileString(_T("eMule"), _T("SkinProfile"), _T(""), strOrigSkin, ARRSIZE(strOrigSkin), thePrefs.strMuleConfigFile);
		WritePrivateProfileString(_T("eMule"), _T("SkinProfileBackup"), strOrigSkin, thePrefs.strMuleConfigFile);
		m_hSkin.Save(strNewSkin);
		ShellExecute(NULL, NULL, thePrefs.strMulePath, strNewSkin, NULL, SW_HIDE);
	}
	else
	{
		GetPrivateProfileString(_T("eMule"), _T("SkinProfileBackup"), _T(""), strOrigSkin, ARRSIZE(strOrigSkin), thePrefs.strMuleConfigFile);
		WritePrivateProfileString(_T("eMule"), _T("SkinProfile"), strOrigSkin, thePrefs.strMuleConfigFile);
		WritePrivateProfileString(_T("eMule"), _T("SkinProfileBackup"), NULL, thePrefs.strMuleConfigFile);
		ShellExecute(NULL, NULL, thePrefs.strMulePath, CString(_T("skin=")) + strOrigSkin, NULL, SW_HIDE);
		CFile::Remove(strNewSkin);
		strOrigSkin[0] = _T('\0');
	}
	m_bPreviewing = bPreview;
	SendMessage(WM_COMMAND, MP_UPDATE_TBBTNS);
}

BOOL CSkinnerDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch (LOWORD(wParam))
	{
		case MP_TB_NEW:
		{
			m_hSkin = theApp.defSkin;
			m_strSkinPath.Empty();
			m_aUndo.RemoveAll();
			m_aRedo.RemoveAll();
			OnSelChange_Groups();
			return true;
		}
		case MP_TB_OPEN:
		{
			OpenLoadDlg();
			return true;
		}
		case MP_TB_SAVE:
		{
			OpenSaveDlg();
			return true;
		}
		case MP_TB_PREVIEW:
		case MP_TB_UNPREVIEW:
		{
			PreviewSkin(wParam == MP_TB_PREVIEW);
			return true;
		}
		case MP_TB_PREFS:
		{
			OpenPrefsDlg();
			return true;
		}
		// --> Note: Do not change this part - Avi3k
		case MP_TB_ABOUT:
		{
			ShowAbout();
			return true;
		}
		case MP_TB_HELP:
		{
			theApp.ShowHelp();
			return true;
		}
		// <-- end note
		case MP_TB_COPY:
		case MP_TB_SELECTALL:
		{
			entrylistctrl.SendMessage(WM_COMMAND, wParam, lParam);
			return true;
		}
		case MP_PASTE:
		case MP_TB_PASTE:
		{
			int curPos = 0, pos;
			CString strLine, strCB = theApp.CopyTextFromClipboard();
			while (curPos != -1)
			{
				strLine = strCB.Tokenize(_T("\r\n"), curPos);
				if ((pos = strLine.Find(_T("="))) > 0)
					ChangeEntry(strLine.Left(pos).Trim(), strLine.Mid(pos+1).Trim());
			}
			OnSelChange_Groups();
			return true;
		}
		case MP_CLEAR:
		case MP_TB_CLEAR:
		{
			POSITION pos = entrylistctrl.GetFirstSelectedItemPosition();
			while (pos)
			{
				int iCurSel = entrylistctrl.GetNextSelectedItem(pos);
				CString strEntry = (LPCTSTR)entrylistctrl.GetItemData(iCurSel);
				ChangeEntry(strEntry, _T(""));
			}
			OnSelChange_Groups();
			return true;
		}

		case MP_SETSKINFILE:
		{
			SetSkinFilePath( (LPCTSTR)lParam );
			return true;
		}
		case MP_EDIT:
		{
			int iRow = (int)lParam;
			CString strEntry = (LPCTSTR)entrylistctrl.GetItemData(iRow);
			CString strVal = entrylistctrl.GetItemText(iRow, entrylistctrl.colValue).Trim();
			ChangeEntry(strEntry, strVal);
			return true;
		}
		case MP_OPENDLG:
		{
			CPoint* pt = (CPoint*)lParam;
			ShowDialog(pt);
			return true;
		}
		case MP_REMOVE:
		{
			return true;
		}
		case MP_UPDATE_TBBTNS:
		{
			bool bMuled = (!thePrefs.strMulePath.IsEmpty() && !thePrefs.strMuleConfigFile.IsEmpty());
			toolbar.SetBtnEnabled(MP_TB_PREVIEW, bMuled && !m_bPreviewing);
			toolbar.SetBtnEnabled(MP_TB_UNPREVIEW, bMuled && m_bPreviewing);

			int iSel = entrylistctrl.GetSelectionMark(), iCount =  entrylistctrl.GetSelectedCount();
			toolbar.SetBtnEnabled(MP_TB_COPY, (iSel != -1 && iCount > 0));
			toolbar.SetBtnEnabled(MP_TB_PASTE, !theApp.CopyTextFromClipboard().IsEmpty());
			toolbar.SetBtnEnabled(MP_TB_CLEAR, (iSel != -1 && iCount > 0));
			return true;
		}
	}
	return CDialog::OnCommand(wParam, lParam);
}

BOOL CSkinnerDlg::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN)
	{
		UINT nChar = (UINT)pMsg->wParam;
		//bool bShift = (bool)(GetAsyncKeyState(VK_SHIFT) < 0);
		bool bCtrl = (bool)(GetAsyncKeyState(VK_CONTROL) < 0);
		if (nChar == _T('S') && bCtrl)
			OpenSaveDlg();
		else if (nChar == _T('O') && bCtrl)
			OpenLoadDlg();
		else if (nChar == _T('N') && bCtrl)
			SendMessage(WM_COMMAND, MP_TB_NEW);
		else if (nChar == _T('Q') && bCtrl)
			OpenPrefsDlg();
		else if (nChar == VK_F2)
			ShowAbout();
		else if (nChar == _T('A') && bCtrl) // Ctrl+A: Select all
			entrylistctrl.SendMessage(WM_COMMAND, MP_SELECTALL);
		else if (nChar == _T('C') && bCtrl) // Ctrl+C: Copy to clipboard
			entrylistctrl.SendMessage(WM_COMMAND, MP_COPY);
		else if (nChar == _T('V') && bCtrl) // Ctrl+V: Paste from clipboard
			SendMessage(WM_COMMAND, MP_PASTE);
		else if (nChar == VK_DELETE) // Delete: Clear items
			SendMessage(WM_COMMAND, MP_CLEAR);
		else if (nChar == _T('Z') && bCtrl) // Ctrl+Z: Undo
			Undo();
		else if (nChar == _T('Y') && bCtrl) // Ctrl+Y: Redo
			Redo();
		else if (nChar == VK_F5 && GetParent()) // F5: Refresh
			OnSelChange_Groups();
		else if (nChar == VK_RETURN)
			return TRUE;
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CSkinnerDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);
	CWnd* pWnd = GetDlgItem(IDC_ENTRYLIST);
	if (!pWnd)
		return;
	CRect rc;
	pWnd->GetWindowRect(&rc);
	ScreenToClient(&rc);
	pWnd->MoveWindow(rc.left, rc.top, cx - 2*rc.left, cy - rc.top - 10);
}

void CSkinnerDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI)
{
	CDialog::OnGetMinMaxInfo(lpMMI);
	lpMMI->ptMinTrackSize = CPoint(485, 220);
}

void CSkinnerDlg::OnDropFiles(HDROP hDropInfo)
{
	TCHAR szPath[MAX_PATH];
	if (DragQueryFile(hDropInfo, 0xFFFFFFFF, NULL, 0) == 1 && DragQueryFile(hDropInfo, 0, szPath, MAX_PATH) > 0)
	{
		CString strSkinPath = szPath;
		if (IsSkinFile(strSkinPath, true) && (!IsArchiveFile(strSkinPath) || ExtractSkin(strSkinPath, true)))
			SetSkinFilePath(strSkinPath);
	}
	CDialog::OnDropFiles(hDropInfo);
}

LRESULT CSkinnerDlg::OnColorPopupEndOK(WPARAM wParam, LPARAM lParam)
{
	COLORREF color = (COLORREF)wParam;
	if (m_strLastColorEntry.IsEmpty() || color == CLR_DEFAULT)
		return TRUE;
	ChangeEntry(m_strLastColorEntry, color2str(color));
	m_strLastColorEntry.Empty();
	OnSelChange_Groups();
	return TRUE;
}

void CSkinnerDlg::ChangeEntry(const CString& strEntry, const CString& strVal)
{
	CString strUndo = strEntry + _T("=") + m_hSkin.GetAt(strEntry);
	if (m_aUndo.GetSize() > 50)
		m_aUndo.RemoveTail();
	m_aUndo.AddHead(strUndo);
	m_aRedo.RemoveAll(); // can only redo after an undo
	m_hSkin.SetAt(strEntry, strVal);
}

void CSkinnerDlg::Undo()
{
	if (m_aUndo.IsEmpty())
		return;
	if (m_aRedo.GetSize() > 50)
		m_aRedo.RemoveTail();
	CString strCurr = m_aUndo.RemoveHead();
	int pos = strCurr.Find(_T("="));
	CString strEntry = strCurr.Left(pos);
	CString strRedo = strEntry + _T("=") + m_hSkin.GetAt(strEntry);
	m_aRedo.AddHead(strRedo);
	m_hSkin.SetAt(strCurr.Left(pos), strCurr.Mid(pos+1));
	OnSelChange_Groups();
}

void CSkinnerDlg::Redo()
{
	if (m_aRedo.IsEmpty())
		return;
	if (m_aUndo.GetSize() > 50)
		m_aUndo.RemoveTail();
	CString strCurr = m_aRedo.RemoveHead();
	int pos = strCurr.Find(_T("="));
	CString strEntry = strCurr.Left(pos);
	CString strUndo = strEntry + _T("=") + m_hSkin.GetAt(strEntry);
	m_aUndo.AddHead(strUndo);
	m_hSkin.SetAt(strCurr.Left(pos), strCurr.Mid(pos+1));
	OnSelChange_Groups();
}

