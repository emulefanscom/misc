//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "SkinnerToolBarCtrl.h"
#include "Skinner.h"
#include "Lang.h"
#include "functions.h"


#ifndef BTNS_SHOWTEXT
#define BTNS_SHOWTEXT		0x0040
#endif
#ifndef TBSTYLE_EX_MIXEDBUTTONS
#define TBSTYLE_EX_MIXEDBUTTONS             0x00000008
#define TBSTYLE_EX_DOUBLEBUFFER             0x00000080
#endif


IMPLEMENT_DYNAMIC(CSkinnerToolBarCtrl, CToolBarCtrl)

CSkinnerToolBarCtrl::CSkinnerToolBarCtrl()
{
}

CSkinnerToolBarCtrl::~CSkinnerToolBarCtrl()
{
	m_imlIcons.DeleteImageList();
}

BEGIN_MESSAGE_MAP(CSkinnerToolBarCtrl, CToolBarCtrl)
END_MESSAGE_MAP()


bool CSkinnerToolBarCtrl::InitToolbar()
{
	ModifyStyle(0, TBSTYLE_TOOLTIPS | CCS_NOMOVEY | CCS_NOPARENTALIGN | CCS_NORESIZE | CCS_NODIVIDER | TBSTYLE_LIST | TBSTYLE_FLAT | TBSTYLE_TRANSPARENT);
	SetExtendedStyle(GetExtendedStyle() | TBSTYLE_EX_MIXEDBUTTONS | TBSTYLE_EX_DOUBLEBUFFER);

	m_imlIcons.DeleteImageList();
	m_imlIcons.Create(18, 18, GetAppImageListColorFlag() | ILC_MASK, 0, 1);
	m_imlIcons.SetBkColor(CLR_NONE);
	m_idxIcons.RemoveAll();
	m_idxIcons.InitHashTable(17);
	SetImageList(&m_imlIcons);

	while (GetButtonCount() > 0)
		DeleteButton(0);

	AddButton(MP_TB_NEW, _T("OpenFile"));
	AddButton(MP_TB_OPEN,  _T("OpenSkin"));
	AddButton(MP_TB_SAVE, _T("SaveSkin"));
	AddSeperator();
	AddButton(MP_TB_PREVIEW, _T("PreviewSkin"));
	AddButton(MP_TB_UNPREVIEW, _T("UnpreviewSkin"));
	AddSeperator();
	AddButton(MP_TB_COPY, _T("Copy"));
	AddButton(MP_TB_PASTE,  _T("Paste"));
	AddButton(MP_TB_CLEAR, _T("Delete"));
	AddButton(MP_TB_SELECTALL, _T("ExportAll"));
	AddSeperator();
	AddButton(MP_TB_PREFS, _T("Preferences"));
	AddButton(MP_TB_ABOUT, _T("SkinnerInfo"));
	AddButton(MP_TB_HELP, _T("SkinnerHelp"));
	return true;
}

void CSkinnerToolBarCtrl::Localize()
{
	SetBtnText(MP_TB_NEW, GetResString(IDS_NEW) + _T(" (Ctrl+N)"));
	SetBtnText(MP_TB_OPEN, GetResString(IDS_LOAD) + _T(" (Ctrl+O)"));
	SetBtnText(MP_TB_SAVE, GetResString(IDS_SAVE) + _T(" (Ctrl+S)"));
	SetBtnText(MP_TB_PREVIEW, GetResString(IDS_PREVIEWSKIN));
	SetBtnText(MP_TB_UNPREVIEW, GetResString(IDS_UNPREVIEWSKIN));
	SetBtnText(MP_TB_COPY, GetResString(IDS_COPY) + _T(" (Ctrl+C)"));
	SetBtnText(MP_TB_PASTE, GetResString(IDS_PASTE) + _T(" (Ctrl+V)"));
	SetBtnText(MP_TB_CLEAR, GetResString(IDS_CLEAR) + _T(" (Del)"));
	SetBtnText(MP_TB_SELECTALL, GetResString(IDS_SELECTALL) + _T(" (Ctrl+A)"));
	SetBtnText(MP_TB_PREFS, GetResString(IDS_PREFERENCES) + _T(" (Ctrl+Q)"));
	SetBtnText(MP_TB_ABOUT, GetResString(IDS_ABOUTSKINNER) + _T(" (F2)"));
	SetBtnText(MP_TB_HELP, GetResString(IDS_HELP) + _T(" (F1)"));
}

bool CSkinnerToolBarCtrl::AddButton(int nCmd, LPCTSTR pszIcon, DWORD dwData)
{
	TBBUTTON btnCmd = {0};
	btnCmd.idCommand = nCmd;
	btnCmd.fsState = TBSTATE_ENABLED;
	btnCmd.fsStyle = TBSTYLE_BUTTON;// | BTNS_SHOWTEXT;
	btnCmd.dwData = dwData;
	btnCmd.iString = -1;
	btnCmd.iBitmap = AddIcon(pszIcon);
	return (AddButtons(1, &btnCmd) != FALSE);
}

bool CSkinnerToolBarCtrl::AddSeperator()
{
	TBBUTTON sepButton = {0};
	sepButton.idCommand = 0;
	sepButton.fsStyle = TBSTYLE_SEP;
	sepButton.fsState = TBSTATE_ENABLED;
	sepButton.iString = sepButton.iBitmap = -1;
	return (AddButtons(1, &sepButton) != FALSE);
}

void CSkinnerToolBarCtrl::SetBtnText(int nID, LPCTSTR pszString)
{
	TBBUTTONINFO tbbi = {0};
	tbbi.cbSize = sizeof(tbbi);
	tbbi.dwMask = TBIF_TEXT;
	tbbi.pszText = const_cast<LPTSTR>(pszString);
	SetButtonInfo(nID, &tbbi);
}

void CSkinnerToolBarCtrl::SetBtnEnabled(int nID, bool bEnabled)
{
	TBBUTTONINFO tbbi = {0};
	tbbi.cbSize = sizeof tbbi;
	tbbi.dwMask = TBIF_STATE;
	tbbi.fsState = (bEnabled) ? TBSTATE_ENABLED : 0;
	SetButtonInfo(nID, &tbbi);
}

int CSkinnerToolBarCtrl::AddIcon(LPCTSTR pszIcon)
{
	int iPos = -1;
	if (!pszIcon || m_idxIcons.Lookup(pszIcon, iPos))
		return iPos;
	iPos = m_imlIcons.Add(CTempIconLoader(pszIcon, 16, 16));
	if (iPos != -1)
		m_idxIcons.SetAt(pszIcon, iPos);
	return iPos;
}
