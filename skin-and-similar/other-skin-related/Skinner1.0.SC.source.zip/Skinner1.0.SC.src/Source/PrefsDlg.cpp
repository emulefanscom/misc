//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "Skinner.h"
#include "PrefsDlg.h"
#include "Preferences.h"
#include "Lang.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


IMPLEMENT_DYNAMIC(CPreferencesDlg, CPropertySheet)

CPreferencesDlg::CPreferencesDlg()
{
	this->m_psh.dwFlags &= ~PSH_HASHELP;
	m_wndSkinner.m_psp.dwFlags &= ~PSH_HASHELP;

	AddPage(&m_wndSkinner);
}

CPreferencesDlg::~CPreferencesDlg()
{
}

BEGIN_MESSAGE_MAP(CPreferencesDlg, CPropertySheet)
END_MESSAGE_MAP()


BOOL CPreferencesDlg::OnInitDialog()
{
	EnableStackedTabs(FALSE);
	BOOL bRet = CPropertySheet::OnInitDialog();

	SetIcon(CTempIconLoader(_T("Preferences")), FALSE);
	ModifyStyleEx(0, WS_EX_TOOLWINDOW);

	Localize();
	SetActivePage(0);

	CTabCtrl* tab = GetTabControl();
	CRect rectOld(0, 0, 0, 0);
	UINT nosizeFlags = SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE;
	UINT nomoveFlags=SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE;
	int xoffset, yoffset, width = 0;
	if (IsWindowVisible())
	{
		yoffset = 0;
		xoffset = width-rectOld.Width();
	}
	else
	{
		xoffset = width-rectOld.Width()+10;
		tab->GetItemRect(0, rectOld);
		yoffset = -rectOld.Height();
	}
	GetWindowRect(rectOld);
	SetWindowPos(NULL, 0, 0, rectOld.Width()+xoffset, rectOld.Height()+yoffset, nomoveFlags);
	tab->GetWindowRect(rectOld);
	ScreenToClient(rectOld);
	tab->SetWindowPos(NULL, rectOld.left+xoffset, rectOld.top+yoffset, 0, 0, nosizeFlags);
	CPropertyPage* activepage = GetActivePage();
	activepage->GetWindowRect(rectOld);
	ScreenToClient(rectOld);
	activepage->SetWindowPos(NULL, rectOld.left+xoffset, rectOld.top+yoffset, 0, 0, nosizeFlags);
	activepage->GetWindowRect(rectOld);
	ScreenToClient(rectOld);
	int _btnIDs[] = {IDOK, IDCANCEL, ID_APPLY_NOW, IDHELP};
	for (int i = 0; i < ARRSIZE(_btnIDs); i++)
	{
		GetDlgItem(_btnIDs[i])->GetWindowRect(rectOld);
		ScreenToClient(rectOld);
		GetDlgItem(_btnIDs[i])->SetWindowPos(NULL, rectOld.left+xoffset, rectOld.top+yoffset, 0, 0, nosizeFlags);
	}
	tab->ShowWindow(SW_HIDE);

	CenterWindow();
	Invalidate();
	RedrawWindow();
	return bRet;
}

void CPreferencesDlg::Localize()
{
	SetWindowText(GetResString(IDS_SKINNERPREFS));
	SetDlgItemText(IDOK, GetResString(IDS_OK));
	SetDlgItemText(IDCANCEL, GetResString(IDS_CANCEL));
	SetDlgItemText(ID_APPLY_NOW, GetResString(IDS_APPLY));
	SetDlgItemText(IDHELP, GetResString(IDS_HELP));
}

