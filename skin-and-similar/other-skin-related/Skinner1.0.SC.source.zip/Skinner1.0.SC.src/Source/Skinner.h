//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#define EMULESKIN_BASEEXT		_T("eMuleSkin")

#include "resource.h"		// main symbols
#include "Skin.h"


class CSkinnerDlg;

class CSkinnerApp : public CWinApp
{
 public:
	CSkinnerApp(LPCTSTR lpszAppName = NULL);
	virtual ~CSkinnerApp();
	virtual BOOL InitInstance();

	const CString& GetVersionStr() const { return m_strVersion; }
	void ShowHelp(LPCTSTR morehelp = NULL);
	bool CopyTextToClipboard(const CString& strText); // from eMule
	CString CopyTextFromClipboard(); // from eMule

	CSkinnerDlg* skinnerdlg;
	CSkin defSkin;

	CString m_strPendingCmd;
	HMODULE m_hMods;

 protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnHelp();

	bool ProcessCmdLine();
	static BOOL CALLBACK SearchSkinnerWindow(HWND hWnd, LPARAM lParam);

 private:
	CString m_strVersion;
	static const UINT m_uSkinnerID;
};

extern CSkinnerApp theApp;

//////////////////////////////////////////////////////////////////////////////
// CTempIconLoader (from eMule)

class CTempIconLoader
{
 public:
	// because nearly all icons we are loading are 16x16, the default size is specified as 16 and not as 32 nor LR_DEFAULTSIZE
	CTempIconLoader(LPCTSTR pszResourceID, int cx = 16, int cy = 16, UINT uFlags = LR_DEFAULTCOLOR);
	~CTempIconLoader();

	HICON LoadIcon(LPCTSTR lpszResourceName, int cx, int cy, UINT uFlags) const;

	operator HICON() const {
		return this == NULL ? NULL : m_hIcon;
	}

 protected:
	HICON m_hIcon;
};

