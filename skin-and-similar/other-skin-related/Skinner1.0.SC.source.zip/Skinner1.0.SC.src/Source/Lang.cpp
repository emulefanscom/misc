//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include <locale.h>
#include "Lang.h"
#include "Skinner.h"
#include "Preferences.h"
#include "ini2.h"
#include "functions.h"

CLanguage theLang;


CLanguage::CLanguage()
{
	m_langID = 0;
}

CLanguage::~CLanguage()
{
}

bool CLanguage::Init()
{
	if (m_strLangDir.IsEmpty() || !PathFileExists(m_strLangDir))
		return false;
	SLanguage* pLangs = sprtLangs+1;
	while (pLangs->lid)
	{
		pLangs->bSupported = PathFileExists(GetLangFileByName(pLangs->name));
		pLangs++;
	}
	return true;
}

void CLanguage::SetLang(LANGID lid)
{
	if (!Init())
		return;
	if (IsLangSupported(lid))
	{
		m_langID = lid;
		//SetThreadLocale(lid);
	}
}

void CLanguage::SetLangDir(const CString& langdir)
{
	m_strLangDir = langdir + (langdir.Right(1) != _T('\\') ? _T("\\") : _T(""));
	if (!PathFileExists(m_strLangDir))
		::CreateDirectory(m_strLangDir, 0);
	if (!PathFileExists(GetLangFileByName(_T("English"))))
		CreateLangFile();
	Init();
}

LANGID CLanguage::GetLang()
{
	return m_langID;
}

void CLanguage::GetAvailableLangs(CLangArray &langs)
{
	Init();
	langs.RemoveAll();
	SLanguage* pLangs = sprtLangs;
	while (pLangs->lid)
	{
		langs.Add(*pLangs);
		pLangs++;
	}
}

CString CLanguage::GetString(const CString& str)
{
	CString strID = CString(str).MakeLower();
	if (strID.Left(4) == _T("ids_"))
		strID = strID.Mid(4);
	CString resStr = GetString(strID, m_langID);
	if (resStr.IsEmpty())
	{
		resStr = GetString(strID, LANGID_EN_US);
		SetString(strID, resStr, m_langID);
	}
	return resStr;
}

CString CLanguage::GetString(const CString& str, LANGID lid)
{
	CString resStr;
	CString lang = GetLangNameByID(lid);
	if (lang.IsEmpty() || !PathFileExists(GetLangFileByName(lang)))
		lang = _T("English");
	CIni ini(GetLangFileByName(lang), lang);
	resStr = ini.GetStringUTF8(str, _T(""));
	resStr.Replace(_T("\\n"), _T("\n"));
	resStr.Replace(_T("\\r"), _T("\r"));
	resStr.Replace(_T("\\t"), _T("\t"));
	return resStr;
}

void CLanguage::SetString(const CString& str, const CString& value, LANGID lid)
{
	CString lang = GetLangNameByID(lid);
	if (lang.IsEmpty())
		return;
	CIni ini(GetLangFileByName(lang), lang);
	CString resStr = value;
	resStr.Replace(_T("\n"),_T("\\n"));
	resStr.Replace(_T("\r"),_T("\\r"));
	resStr.Replace(_T("\t"),_T("\\t"));
	ini.WriteStringUTF8(str, resStr);
}

CString CLanguage::GetLangLocalName(LANGID lid)
{
	TCHAR szLang[128];
	GetLocaleInfo(lid, LOCALE_SLANGUAGE, szLang, ARRSIZE(szLang));
	return szLang;
}

CString CLanguage::GetLangCode(LANGID lid)
{
	SLanguage* pLangs = sprtLangs;
	while (pLangs->lid)
	{
		if (pLangs->lid == lid)
			return pLangs->code;
		pLangs++;
	}
	return _T("en");
}

CString CLanguage::GetLangNameByID(LANGID lid)
{
	SLanguage* pLangs = sprtLangs;
	while (pLangs->lid)
	{
		if (pLangs->lid == lid)
			return pLangs->name;
		pLangs++;
	}
	return _T("");
}

CString CLanguage::GetLangFileByName(const CString& name)
{
	CString buffer;
	buffer.Format(_T("%s%s.ini"), m_strLangDir, (name.IsEmpty()) ? _T("English") : name);
	return buffer;
}

CString CLanguage::GetLangFileByID(LANGID lid)
{
	CString buffer;
	SLanguage* pLangs = sprtLangs;
	while (pLangs->lid)
	{
		if (pLangs->lid == lid)
			return GetLangFileByName(pLangs->name);
		pLangs++;
	}
	return _T("");
}

bool CLanguage::IsLangSupported(LANGID lid)
{
	SLanguage* pLangs = sprtLangs;
	while (pLangs->lid)
	{
		if (pLangs->lid == lid)
			return pLangs->bSupported;
		pLangs++;
	}
	return false;
}

bool CLanguage::CheckLangVersion(LANGID lid)
{
	if (lid == LANGID_EN_US)
		return true;
	SLanguage* pLangs = sprtLangs+1;
	while (pLangs->lid)
	{
		if (pLangs->lid == lid)
		{
			CIni ini(GetLangFileByName(pLangs->name), pLangs->name);
			return (ini.GetString(_T("LangVer")) == theApp.GetVersionStr());
		}
		pLangs++;
	}
	return false;
}

bool CLanguage::DownloadLang(LANGID lid)
{
	if (!thePrefs.usenetconns || lid == LANGID_EN_US || (IsLangSupported(lid) && CheckLangVersion(lid)))
		return false;

	CString strUrl;
	strUrl.Format(_T("skinnerlangs.php?lang=%s&v=%s"), GetLangCode(lid), theApp.GetVersionStr());
	CArray<char> acLang;
	if (!ReadNetFile(strUrl, acLang))
		return false;
	//CString tmplang = AsciiToUTF8String(acLang.GetData(), true, acLang.GetCount());
	CStdioFile txtfile;
	CString strLang = GetLangNameByID(lid);
	if (!strLang.CompareNoCase(_T("English")))
		return false;
	CString txtfilename = GetLangFileByName(strLang); ///m_strLangDir + _T("tmplang.ini");
	if (!txtfile.Open(txtfilename, CFile::modeWrite | CFile::typeText | CFile::shareExclusive | CFile::modeCreate))
		return false;

	txtfile.Write(acLang.GetData(), acLang.GetCount());
	txtfile.Close();
	Init();
	return true;
}

void CLanguage::CreateLangFile()
{
	SLangEntry* pEntry = _langEntries;
	CIni ini(GetLangFileByName(_T("English")), _T("English"));
	while (pEntry->entry)
	{
		ini.WriteStringUTF8(pEntry->entry, pEntry->defval);
		pEntry++;
	}
}

