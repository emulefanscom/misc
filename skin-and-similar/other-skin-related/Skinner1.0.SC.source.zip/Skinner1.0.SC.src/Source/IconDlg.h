
#pragma once
#include "resource.h"

class CIconDialog : public CDialog
{
 public:
	CIconDialog(CWnd* pParent = NULL);

	BOOL SetIcon(const CString& sFilename, int nIndex);
	void GetIcon(CString& sFilename, int& nIconIndex);
	void Localize();

	enum { IDD = IDD_ICONDIALOG };

 protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	void UpdateIconList();
	afx_msg void OnBrowse();
	afx_msg void OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnDestroy();
	virtual void OnOK();
	afx_msg void OnDblclkIconlist();
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

 private:
	CListBox m_ctrlIconList;
	CString m_sFilename;
	int m_nIconIndex;
};
