//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#ifndef SKINNER_UMC
#define SKINNER_UMC

#pragma once

// Toolbar IDs
#define MP_TB_NEW		10001
#define MP_TB_OPEN		10002
#define MP_TB_SAVE		10003
#define MP_TB_PREVIEW		10004
#define MP_TB_UNPREVIEW	10005
#define MP_TB_COPY		10006
#define MP_TB_PASTE		10007
#define MP_TB_CLEAR		10008
#define MP_TB_SELECTALL		10009
#define MP_TB_PREFS		10010
#define MP_TB_ABOUT		10011
#define MP_TB_HELP		10012

// Menu Commands
#define MP_EDIT			11001
#define MP_OPENDLG		11002
#define MP_REMOVE		11003
#define MP_COPY			11004
#define MP_PASTE		11005
#define MP_CLEAR		11006
#define MP_SELECTALL		11007
#define MP_UPDATE_TBBTNS	11008
#define MP_SETSKINFILE		11009




// ALL WM_USER messages are to be declared here *after* 'WM_FIRST_SKINNER_USER_MSG' // from eMule
enum EUserWndMsgs
{
	// *) Do *NOT* place any message *before* WM_FIRST_SKINNER_USER_MSG !!
	// *) Do *NOT* use any WM_USER messages in the range WM_USER - WM_USER+0x100 !!
	UM_FIRST_SKINNER_USER_MSG = (WM_USER + 0x100 + 1),

	WM_TREEOPTSCTRL_NOTIFY,

	UM_CPN_SELCHANGE,
	UM_CPN_DROPDOWN,
	UM_CPN_CLOSEUP,
	UM_CPN_SELENDOK,
	UM_CPN_SELENDCANCEL
};

#endif
