//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#include "stdafx.h"
#include "Skin.h"
#include "Skinner.h"
#include "ini2.h"
#include "Preferences.h"


CSkin::CSkin()
{
	m_hSkin.InitHashTable(317);
	for (const skinSection* paInfo = _skinInfo; paInfo && paInfo->pszName && _tcsicmp(paInfo->pszName, _T("Skinfo")); paInfo++)
	{
		for (const skinGroup* paGrp = paInfo->aGroups; paGrp && paGrp->pszName; paGrp++)
		{
			for (LPCTSTR* paEntry = (LPCTSTR*)paGrp->aItems; paEntry && *paEntry; paEntry++)
				m_hSkin[*paEntry] = _T("");
		}
	}
}

CSkin::CSkin(const CSkin& skin)
{
	*this = skin;
}

CString CSkin::GetAt(const CString& strKey)
{
	if (strKey.Left(7).MakeLower() == _T("skinfo_"))
		return GetSkinfoVal(strKey.Mid(7));
	CString strVal;
	m_hSkin.Lookup(strKey, strVal);
	return strVal;
}

bool CSkin::SetAt(const CString& strKey, const CString& strVal)
{
	if (strKey.Left(7).MakeLower() == _T("skinfo_"))
		return SetSkinfoVal(strKey.Mid(7), strVal);
	m_hSkin[strKey] = strVal;
	return true;
}

CString CSkin::GetSkinfoVal(const CString& strKey)
{
	CString sKey = strKey;
	sKey.MakeLower();
	if (sKey == _T("author"))
		return m_info.strAuthor;
	else if (sKey == _T("skinname"))
		return m_info.strSkinName;
	else if (sKey == _T("skinversion"))
		return m_info.strSkinVersion;
	return _T("");
}

bool CSkin::SetSkinfoVal(const CString& strKey, const CString& strVal)
{
	CString sKey = strKey;
	sKey.MakeLower();
	if (sKey == _T("author"))
		m_info.strAuthor = strVal;
	else if (sKey == _T("skinname"))
		m_info.strSkinName = strVal;
	else if (sKey == _T("skinversion"))
		m_info.strSkinVersion = strVal;
	else // currently date & app are unchanged
		return false;
	return true;
}

void CSkin::RemoveFromEntries(const CString& strRm)
{
	POSITION pos = m_hSkin.GetStartPosition();
	CString strKey, strVal;
	while (pos)
	{
		m_hSkin.GetNextAssoc(pos, strKey, strVal);
		strVal.Replace(strRm, _T(""));
		m_hSkin[strKey] = strVal;
	}
}


bool CSkin::Load(const CString& strSkinPath)
{
	CIni ini(strSkinPath);
	ReadSkinfo(ini, m_info);
	for (const skinSection* paInfo = _skinInfo; paInfo && paInfo->pszName && _tcsicmp(paInfo->pszName, _T("Skinfo")); paInfo++)
	{
		for (const skinGroup* paGrp = paInfo->aGroups; paGrp && paGrp->pszName; paGrp++)
		{
			for (LPCTSTR* paEntry = (LPCTSTR*)paGrp->aItems; paEntry && *paEntry; paEntry++)
				m_hSkin[*paEntry] = ini.GetStringUTF8(*paEntry, theApp.defSkin.GetAt(*paEntry), paInfo->pszName);
		}
	}
	return true;
}

bool CSkin::Save(const CString& strSkinPath)
{
	CIni ini(strSkinPath);
	WriteSkinfo(ini, m_info);
	for (const skinSection* paInfo = _skinInfo; paInfo && paInfo->pszName && _tcsicmp(paInfo->pszName, _T("Skinfo")); paInfo++)
	{
		for (const skinGroup* paGrp = paInfo->aGroups; paGrp && paGrp->pszName; paGrp++)
		{
			for (LPCTSTR* paEntry = (LPCTSTR*)paGrp->aItems; paEntry && *paEntry; paEntry++)
			{
				CString strVal(GetAt(*paEntry));
				if (!strVal.IsEmpty())
					ini.WriteStringUTF8(*paEntry, strVal, paInfo->pszName);
			}
		}
	}
	return true;
}


CSkin& CSkin::operator=(const CSkin& skin)
{
	POSITION pos = skin.m_hSkin.GetStartPosition();
	CString strKey, strVal;
	m_hSkin.RemoveAll();
	m_hSkin.InitHashTable(skin.m_hSkin.GetHashTableSize()+37);
	while (pos)
	{
		skin.m_hSkin.GetNextAssoc(pos, strKey, strVal);
		m_hSkin[strKey] = strVal;
	}
	m_info = skin.m_info;
	return *this;
}


void CSkin::WriteSkinfo(CIni& ini, const Skinfo& info)
{
	CString strSection = ini.GetSection();
	ini.SetSection(_T("Skinfo"));
	ini.WriteStringUTF8(_T("Skinfo_Author"), info.strAuthor);
	ini.WriteStringUTF8(_T("Skinfo_SkinName"), info.strSkinName);
	ini.WriteStringUTF8(_T("Skinfo_SkinVersion"), info.strSkinVersion);
	ini.WriteStringUTF8(_T("Skinfo_Date"), info.strDate);
	ini.WriteStringUTF8(_T("Skinfo_App"), info.strApp);
	ini.SetSection(strSection);
}

void CSkin::ReadSkinfo(CIni& ini, Skinfo& info)
{
	CString strSection = ini.GetSection();
	ini.SetSection(_T("Skinfo"));
	info.strAuthor = ini.GetStringUTF8(_T("Skinfo_Author"), _T(""));
	info.strSkinName = ini.GetStringUTF8(_T("Skinfo_SkinName"), _T(""));
	info.strSkinVersion = ini.GetStringUTF8(_T("Skinfo_SkinVersion"), _T(""));
	info.strDate = ini.GetStringUTF8(_T("Skinfo_Date"), _T(""));
	info.strApp = ini.GetStringUTF8(_T("Skinfo_App"), _T("Skinner"));
	if (info.strApp.IsEmpty() || info.strApp.Left(7).MakeLower() == _T("skinner"))
		info.strApp = _T("Skinner") + theApp.GetVersionStr();
	if (info.strDate.IsEmpty())
	{
		TCHAR szBuff[32];
		time_t tNow = time(NULL);
		_tcsftime(szBuff, ARRSIZE(szBuff), _T("%Y-%m-%d, %H:%M"), localtime(&tNow));
		info.strDate = szBuff;
	}
	ini.SetSection(strSection);
}

