//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "MenuEx.h"
#include "Skinner.h"
#include "functions.h"
#include "Preferences.h"


#define MIIM_BITMAP      0x00000080
#define HBMMENU_CALLBACK ((HBITMAP) -1)

typedef struct tagMENUITEMINFOWEX
{
    UINT     cbSize;
    UINT     fMask;
    UINT     fType;         // used if MIIM_TYPE (4.0) or MIIM_FTYPE (>4.0)
    UINT     fState;        // used if MIIM_STATE
    UINT     wID;           // used if MIIM_ID
    HMENU    hSubMenu;      // used if MIIM_SUBMENU
    HBITMAP  hbmpChecked;   // used if MIIM_CHECKMARKS
    HBITMAP  hbmpUnchecked; // used if MIIM_CHECKMARKS
    ULONG_PTR dwItemData;   // used if MIIM_DATA
    LPWSTR   dwTypeData;    // used if MIIM_TYPE (4.0) or MIIM_STRING (>4.0)
    UINT     cch;           // used if MIIM_TYPE (4.0) or MIIM_STRING (>4.0)
    HBITMAP  hbmpItem;      // used if MIIM_BITMAP
}   MENUITEMINFOEX, FAR *LPMENUITEMINFOEX;

CMenuEx::CMenuEx()
{
	m_ImageList.DeleteImageList();
	m_ImageList.Create(16, 16, GetAppImageListColorFlag() | ILC_MASK, 0, 1);
	m_ImageList.SetBkColor(CLR_NONE);
}

CMenuEx::~CMenuEx()
{
	DeleteIcons();
}

BOOL CMenuEx::CreateMenu()
{
	BOOL bRes = CMenu::CreateMenu();
	DeleteIcons();
	m_ImageList.Create(16, 16, GetAppImageListColorFlag() | ILC_MASK, 0, 1);
	m_ImageList.SetBkColor(CLR_NONE);
	return bRes;
}

BOOL CMenuEx::CreatePopupMenu()
{
	BOOL bRes = CMenu::CreatePopupMenu();
	DeleteIcons();
	m_ImageList.Create(16, 16, GetAppImageListColorFlag() | ILC_MASK, 0, 1);
	m_ImageList.SetBkColor(CLR_NONE);
	return bRes;
}

BOOL CMenuEx::DestroyMenu()
{
	BOOL bRes = CMenu::DestroyMenu();
	DeleteIcons();
	return bRes;
}

void CMenuEx::DeleteIcons()
{
	m_ImageList.DeleteImageList();
	m_mapIconPos.RemoveAll();
	POSITION pos = m_mapIconNameToBitmap.GetStartPosition();
	CString strKey;
	void *pvBmp;
	while (pos)
	{
		m_mapIconNameToBitmap.GetNextAssoc(pos, strKey, pvBmp);
		VERIFY( DeleteObject((HBITMAP)pvBmp) );
	}
	m_mapIconNameToBitmap.RemoveAll();
}

BOOL CMenuEx::AppendMenu(UINT nFlags, UINT_PTR nIDNewItem, LPCTSTR lpszNewItem, LPCTSTR lpszIconName)
{
	BOOL bResult = CMenu::AppendMenu(nFlags, nIDNewItem, lpszNewItem);
	if (bResult)
		SetMenuBitmap(nFlags, nIDNewItem, lpszNewItem, lpszIconName);
	return bResult;
}

BOOL CMenuEx::InsertMenu(UINT nPosition, UINT nFlags, UINT_PTR nIDNewItem, LPCTSTR lpszNewItem, LPCTSTR lpszIconName)
{
	BOOL bResult = CMenu::InsertMenu(nPosition, nFlags, nIDNewItem, lpszNewItem);
	if (bResult)
		SetMenuBitmap(nFlags, nIDNewItem, lpszNewItem, lpszIconName);
	return bResult;
}

void CMenuEx::MeasureItem(LPMEASUREITEMSTRUCT lpMIS)
{
	CMenu::MeasureItem(lpMIS);
	if (thePrefs.GetWindowsVersion() >= _WINVER_NT4)
	{
		lpMIS->itemHeight = max(lpMIS->itemHeight, 16) + 2;
		lpMIS->itemWidth += 8;
	}
}

void CMenuEx::DrawItem(LPDRAWITEMSTRUCT lpDIS)
{
	CDC* dc = CDC::FromHandle(lpDIS->hDC);
	int posY = lpDIS->rcItem.top + ((lpDIS->rcItem.bottom - lpDIS->rcItem.top) - 16) / 2;
	int nIconPos;
	if (!m_mapIconPos.Lookup(lpDIS->itemID, nIconPos))
		return;
	if ((lpDIS->itemState & ODS_GRAYED) != 0 && DrawGrayIcon(*dc, m_ImageList.ExtractIcon(nIconPos), CPoint(lpDIS->rcItem.left-15, posY), (lpDIS->itemState & ODS_SELECTED)))
		return;
	m_ImageList.Draw(dc, nIconPos, CPoint(lpDIS->rcItem.left-15, posY), ILD_TRANSPARENT);
}

void CMenuEx::SetMenuBitmap(UINT nFlags, UINT_PTR nIDNewItem, LPCTSTR /*lpszNewItem*/, LPCTSTR lpszIconName)
{
	if (!lpszIconName || (nFlags & MF_SEPARATOR) != 0 || thePrefs.GetWindowsVersion() < _WINVER_NT4 /* no icons on win9x */)
		return;

	// Those MFC warnings which are thrown when one opens certain context menus are because of sub menu items.
	// All the IDs shown in the warnings are sub menu handles! Seems to be a bug in MFC. Look at '_AfxFindPopupMenuFromID'.
	// ---
	// Warning: unknown WM_MEASUREITEM for menu item 0x530601.
	// Warning: unknown WM_MEASUREITEM for menu item 0x4305E7.
	// ---
	//if (nFlags & MF_POPUP)
	//	TRACE(_T("MenuEx: adding popup menu item id=%x  str=%s\n"), nIDNewItem, lpszNewItem);

	MENUITEMINFOEX info = {0};
	info.fMask = MIIM_BITMAP;
	info.cbSize = sizeof(info);

	if (thePrefs.GetWindowsVersion() >= _WINVER_VISTA) // use HBITMAP on vista (from eMule)
	{
		CString strIconLower(lpszIconName);
		strIconLower.MakeLower();
		HBITMAP hBmp = NULL;
		void *pvBmp;
		if (m_mapIconNameToBitmap.Lookup(strIconLower, pvBmp))
		{
			hBmp = (HBITMAP)pvBmp;
		}
		else
		{
			CImage img;
			CTempIconLoader hIcon(lpszIconName, 16, 16);
			if (hIcon && img.Create(16, 16, 32, CImage::createAlphaChannel))
			{
				DrawIconEx(img.GetDC(), 0, 0, hIcon, 16, 16, 0, NULL, DI_NORMAL);
				img.ReleaseDC();
				hBmp = img.Detach();
			}
		}
		if (hBmp)
		{
			info.hbmpItem = hBmp;
			VERIFY( SetMenuItemInfo(nIDNewItem, (MENUITEMINFO *)&info, FALSE) );
			m_mapIconNameToBitmap.SetAt(strIconLower, hBmp);
			return;
		}
	}

	info.hbmpItem = HBMMENU_CALLBACK;
	VERIFY( SetMenuItemInfo(nIDNewItem, (MENUITEMINFO*)&info, FALSE) );

	int nPos = m_ImageList.Add(CTempIconLoader(lpszIconName));
	if (nPos != -1)
		m_mapIconPos.SetAt(nIDNewItem, nPos);
}

