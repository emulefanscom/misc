//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once


class CPreferences
{
 public:	// variables
	static bool confirmexit;
	static bool usenetconns;
	static bool check4update;
	static uint64 compatiblemods;
	static CString skinname;
	static CString skinprofile;
	static CString skinprofiledir;
	static bool skinprofile_loaded;
	static bool skinprofile_saved;
	static CString strMulePath;
	static CString strMuleConfigFile; // not stored!!!
	static DWORD dwWinVer; // not stored!

 public:	// function members
	CPreferences();
	virtual ~CPreferences();

	void Init();
	void Uninit();
	void Load();
	void Save();

	const CString& GetAppDir() const { return appdir; }

	bool CheckForNewVersion();

	const CString& GetSkinName() const { return skinname; }
	CString GetSkinFileName(const CString& strName = _T(""));
	const CString& GetSkinProfile() const { return skinprofile; }
	void SetSkinProfile(const CString& strPath) { skinprofile = strPath; }
	const CString& GetSkinProfileDir() const { return skinprofiledir; }
	void SetSkinProfileDir(const CString& path);
	bool SkinProfileSettings();

	const bool IsModCompatible(uint64 mod);
	void SetModCompatible(uint64 mod, bool bCompat);

	const DWORD GetWindowsVersion() const { return dwWinVer; }

 private:
	CString appdir;
	CString skinnerver;
};

extern CPreferences thePrefs;

