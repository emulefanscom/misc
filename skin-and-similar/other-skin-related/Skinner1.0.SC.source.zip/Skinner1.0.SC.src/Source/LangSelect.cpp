//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "LangSelect.h"
#include "Skinner.h"
#include "Preferences.h"
#include "Lang.h"
#include "functions.h"


// lang combo box
CTreeOptionsLangCombo::CTreeOptionsLangCombo()
{
}

CTreeOptionsLangCombo::~CTreeOptionsLangCombo()
{
}

IMPLEMENT_DYNCREATE(CTreeOptionsLangCombo, CTreeOptionsCombo)

BEGIN_MESSAGE_MAP(CTreeOptionsLangCombo, CTreeOptionsCombo)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_CONTROL_REFLECT(CBN_SELCHANGE, OnCbnSelchange)
END_MESSAGE_MAP()


int CTreeOptionsLangCombo::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeOptionsCombo::OnCreate(lpCreateStruct) == -1)
		return -1;

	CLangArray langs;
	theLang.GetAvailableLangs(langs);

	m_imlLang.DeleteImageList();
	m_imlLang.Create(14, 10, GetAppImageListColorFlag() | ILC_MASK, 0, 1);
	m_imlLang.SetBkColor(CLR_NONE);
	for (int i = 0; i < langs.GetCount(); i++)
	{
		int iSel = AddItem(theLang.GetLangLocalName(langs[i].lid), langs[i].name);
		if (langs[i].lid == theLang.GetLang())
			SetCurSel(iSel);
	}
	SetImageList(&m_imlLang);

	CRect rcCombo, rcTree;
	GetWindowRect(&rcCombo);
	ScreenToClient(&rcCombo);
	((CTreeOptionsCtrlEx*)m_pTreeCtrl)->GetWindowRect(&rcTree);
	ScreenToClient(&rcTree);
	SetDroppedWidth(abs(rcTree.right - rcCombo.left));

	return 0;
}

void CTreeOptionsLangCombo::OnDestroy()
{
	CComboBoxEx::OnDestroy();
	m_imlLang.DeleteImageList();
}

void CTreeOptionsLangCombo::OnCbnSelchange()
{
	((CTreeOptionsCtrlEx*)m_pTreeCtrl)->NotifyParent((UINT)this, m_hTreeCtrlItem);
}

int CTreeOptionsLangCombo::AddItem(LPCTSTR pszText, LPCTSTR pszIcon)
{
	COMBOBOXEXITEM cbi = {0};
	cbi.mask = CBEIF_TEXT;
	cbi.iItem = -1;
	cbi.pszText = (LPTSTR)pszText;
	int nIcon = -1;
	if (pszIcon != NULL)
	{
		nIcon = m_imlLang.Add(CTempIconLoader(pszIcon));
	}
	if (nIcon != -1)
	{
		cbi.mask |= CBEIF_IMAGE | CBEIF_SELECTEDIMAGE;
		cbi.iImage = cbi.iSelectedImage = nIcon;
	}
	return InsertItem(&cbi);
}


// lang button
CTreeOptionsLangButton::CTreeOptionsLangButton()
{
}

CTreeOptionsLangButton::~CTreeOptionsLangButton()
{
}

IMPLEMENT_DYNCREATE(CTreeOptionsLangButton, CTreeOptionsBrowseButton)

BEGIN_MESSAGE_MAP(CTreeOptionsLangButton, CTreeOptionsBrowseButton)
	ON_WM_CREATE()
END_MESSAGE_MAP()

int CTreeOptionsLangButton::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeOptionsBrowseButton::OnCreate(lpCreateStruct) == -1)
		return -1;

	SetWindowText(GetResString(IDS_UPDATE));
	EnableWindow(thePrefs.usenetconns);

	return 0;
}

void CTreeOptionsLangButton::BrowseForOpaque()
{
	((CTreeOptionsCtrlEx*)m_pTreeCtrl)->NotifyParent((UINT)this, m_hTreeCtrlItem);
}

int CTreeOptionsLangButton::GetWidth()
{
	CString strText = GetResString(IDS_UPDATE);
	return ((strText.GetLength() + 1) * 8 + 4);
}

