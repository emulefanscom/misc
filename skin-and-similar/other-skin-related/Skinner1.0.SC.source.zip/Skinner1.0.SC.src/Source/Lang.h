//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once

#define LANGID_EN_US MAKELANGID(LANG_ENGLISH,SUBLANG_DEFAULT)
#define LANGID_HE_IL MAKELANGID(LANG_HEBREW,SUBLANG_DEFAULT)
#define LANGID_ES_ES MAKELANGID(LANG_SPANISH,SUBLANG_SPANISH)
#define LANGID_DE_DE MAKELANGID(LANG_GERMAN,SUBLANG_DEFAULT)
#define LANGID_DA_DK MAKELANGID(LANG_DANISH,SUBLANG_DEFAULT)
#define LANGID_FR_FR MAKELANGID(LANG_FRENCH,SUBLANG_DEFAULT)
#define LANGID_IT_IT MAKELANGID(LANG_ITALIAN,SUBLANG_DEFAULT)
#define LANGID_PL_PL MAKELANGID(LANG_POLISH,SUBLANG_DEFAULT)
#define LANGID_CZ_CZ MAKELANGID(LANG_CZECH,SUBLANG_DEFAULT)
#define LANGID_PT_PT MAKELANGID(LANG_PORTUGUESE,SUBLANG_PORTUGUESE)
#define LANGID_NL_NL MAKELANGID(LANG_DUTCH,SUBLANG_DEFAULT)
#define LANGID_CN_CN MAKELANGID(LANG_CHINESE,SUBLANG_CHINESE_SIMPLIFIED)


#define GetResString(str)		theLang.GetString(_T(#str))

typedef struct SLanguage
{
	LANGID lid;
	LPCTSTR name;
	LPCTSTR code;
	bool bSupported;
} SLanguage;

typedef struct SLangEntry
{
	LPCTSTR entry;
	LPCTSTR defval;
} SLangEntry;

typedef CArray<SLanguage, SLanguage> CLangArray;


static SLanguage sprtLangs[] =
{
	{ LANGID_EN_US,	_T("English"),	_T("en"),	true },
	{ LANGID_HE_IL,	_T("Hebrew"),	_T("he"),	false },
	{ LANGID_ES_ES,	_T("Spanish"),	_T("es"),	false },
	{ LANGID_DE_DE,	_T("German"),	_T("de"),	false },
	{ LANGID_DA_DK,	_T("Danish"),	_T("dk"),	false },
	{ LANGID_FR_FR,	_T("French"),	_T("fr"),	false },
	{ LANGID_IT_IT,	_T("Italian"),	_T("it"),	false },
	{ LANGID_PL_PL,	_T("Polish"),	_T("pl"),	false },
	{ LANGID_CZ_CZ,	_T("Czech"),	_T("cz"),	false },
	{ LANGID_PT_PT,	_T("Portuguese"),	_T("pt"),	false },
	{ LANGID_NL_NL,	_T("Dutch"),	_T("nl"),	false },
	{ LANGID_CN_CN,	_T("ChineseSimplified"),	_T("cn"),	false },
	{ 0, NULL, NULL }
};

static SLangEntry _langEntries[] =
{
	{ _T("OK"), _T("OK") },
	{ _T("Cancel"), _T("Cancel") },
	{ _T("Apply"), _T("Apply") },
	{ _T("Help"), _T("Help") },
	{ _T("Close"), _T("Close") },
	{ _T("AllRights"), _T("All rights reserved") },
	{ _T("ReleasedGPL"), _T("Released under the GPL license (Open Source)!") },
	{ _T("Browse"), _T("Browse") },
	{ _T("New"), _T("New Skin") },
	{ _T("Save"), _T("Save Skin") },
	{ _T("Load"), _T("Load Skin") },
	{ _T("Preferences"), _T("Preferences") },
	{ _T("SkinnerPrefs"), _T("Skinner Preferences") },
	{ _T("AboutSkinner"), _T("About eMule Skinner") },
	{ _T("PreviewSkin"), _T("Preview Skin") },
	{ _T("UnpreviewSkin"), _T("Cancel Skin preview") },
	{ _T("Entry"), _T("Entry") },
	{ _T("Color"), _T("Color") },
	{ _T("Colors"), _T("Colors") },
	{ _T("Icon"), _T("Icon") },
	{ _T("Icons"), _T("Icons") },
	{ _T("Bitmaps"), _T("Bitmaps") },
	{ _T("HTML"), _T("HTML") },
	{ _T("Skinfo"), _T("Skin info.") },
	{ _T("Section"), _T("Section") },
	{ _T("IconLibrary"), _T("Icon Library") },
	{ _T("Edit"), _T("Edit entry") },
	{ _T("Copy"), _T("Copy entry") },
	{ _T("Paste"), _T("Paste entry") },
	{ _T("Clear"), _T("Clear selected") },
	{ _T("SelectAll"), _T("Select All") },
	{ _T("RemoveString"), _T("Remove from entry") },
	{ _T("AllFiles"), _T("All Files") },
	{ _T("SkinFile"), _T("eMule Skin file") },
	{ _T("SkinFileZipped"), _T("eMule Zipped Skin file") },
	{ _T("SkinFileRarred"), _T("eMule Rarred Skin file") },
	{ _T("CommonImageFiles"), _T("Common image files") },
	{ _T("HtmlPageFiles"), _T("HTML page files") },
	{ _T("SpecifyFile"), _T("Specify a file") },
	{ _T("SpecifyFolder"), _T("Specify a folder") },
	{ _T("SelectImage"), _T("Select an image") },
	{ _T("SelectHtmlPage"), _T("Select an HTML page") },
	{ _T("KeepCurrent"), _T("Keep current") },
	{ _T("More"), _T("More...") },
	{ _T("True"), _T("True") },
	{ _T("False"), _T("False") },
	{ _T("ConfirmExit"), _T("Are you sure you want to quit Skinner?\\n\\nNote: to quit and save your Skin, click No and use the Save button.") },
	{ _T("PromptOnExit"), _T("Propmt on exit") },
	{ _T("eMulePath"), _T("eMule's executable path") },
	{ _T("Restart"), _T("For the changes to take effect, please save your skin and restart Skinner!") },
	{ _T("PrefsWarning"), _T("If you don't understand these Preferences, please don't change them! Skinner will work fine without changing these Preferences.") },
	{ _T("CompatibleMods"), _T("Allow Skinner to make the skins compatible to eMule mods") },
	{ _T("SkinProfilePrefs"), _T("Skin profile settings") },
	{ _T("SkinName"), _T("Skin default name") },
	{ _T("SkinProfile"), _T("Skin profile") },
	{ _T("SkinProfileDir"), _T("Skin profile directory") },
	{ _T("SkinProfileLoaded"), _T("Save skin profile when loading skin") },
	{ _T("SkinProfileSaved"), _T("Save skin profile when saving skin") },
	{ _T("SkinnerLang"), _T("Skinner language") },
	{ _T("DownloadLang"), _T("The selected language is not available.\\nWould you like to Download this language?") },
	{ _T("Update"), _T("Update") },
	{ _T("NetConnsPrefs"), _T("Internet connection settings") },
	{ _T("UseNetConnections"), _T("Allow Skinner to use Internet connection related functions") },
	{ _T("CheckForUpdate"), _T("Check for new version of Skinner at startup") },
	{ _T("DetectedNewVersion"), _T("Skinner has detected a new version.\\nWould you like to check the homepage for details?\\n\\nNote: click Cancel to never prompt this message again.") },
	{ _T("IconDlgFileName"), _T("File name") },
	{ _T("IconDlgCurrentIcon"), _T("Current icon") },
	{ _T("IconDlgCaption"), _T("Choose Icon") },
	{ _T("IconDlgSelectIcon"), _T("Please select an icon") },
	{ _T("IconDlgNoIcon"), _T("The file '%s' contains no icons") },
	{ _T("IconDlgNotAFile"), _T("Cannot find the file '%s', Please select another file") },
	{ _T("OpenDlg"), _T("Open dialog") },
	{ _T("Separator"), _T("-------------------------") },
	{ _T("ColorsDefault"), _T("Default colors") },
	{ _T("ColorsServer"), _T("Server list colors") },
	{ _T("ColorsSearchResult"), _T("Search results list colors") },
	{ _T("ColorsDownload"), _T("Download list colors") },
	{ _T("ColorsUpload"), _T("Upload list colors") },
	{ _T("ColorsQueue"), _T("Queue list colors") },
	{ _T("ColorsClients"), _T("Clients list colors") },
	{ _T("ColorsFriends"), _T("Friends list colors") },
	{ _T("ColorsIRCnick"), _T("IRC nick list colors") },
	{ _T("ColorsIRCchannels"), _T("IRC channels list colors") },
	{ _T("ColorsShared"), _T("Shared files list colors") },
	{ _T("ColorsKadContact"), _T("Kademlia contact list colors") },
	{ _T("ColorsKadAction"), _T("Kademlia action list colors") },
	{ _T("ColorsStats"), _T("Statistics infobox colors") },
	{ _T("ColorsLogWin"), _T("Log window colors") },
	{ _T("ColorsVerboseLogWin"), _T("Verbose Log window colors") },
	{ _T("ColorsServerLogWin"), _T("Server info window colors") },
	{ _T("ColorsChatWin"), _T("Chat windows colors") },
	{ _T("ColorsIRCWin"), _T("IRC status, channel windows colors") },
	{ _T("IconsToolbar"), _T("Toolbar buttons icons (32x32)") },
	{ _T("IconsPrefs"), _T("Prefs dialog buttons icons (16x16)") },
	{ _T("IconsClients"), _T("Clients icons (plus = has credit)") },
	{ _T("IconsSources"), _T("Source states") },
	{ _T("IconsFileRates"), _T("File ratings icons") },
	{ _T("IconsFriends"), _T("Friend types icons") },
	{ _T("IconsFriendsMenu"), _T("Friend menu icons") },
	{ _T("IconsKadWin"), _T("Kademlia window") },
	{ _T("IconsKadSearch"), _T("Kademlia search actions") },
	{ _T("IconsKadContact"), _T("Kad contact type (0=good ... 4=dead)") },
	{ _T("IconsSearchWin"), _T("Search window icons") },
	{ _T("IconsSearchMethod"), _T("Search methods icons") },
	{ _T("IconsSearchFileTypes"), _T("Search file types icons") },
	{ _T("IconsStatsWin"), _T("Statistics window icons") },
	{ _T("IconsStatusbar"), _T("Statusbar/Statistics icons") },
	{ _T("IconsServerWin"), _T("Server window icons") },
	{ _T("IconsTransferWin"), _T("Transfer window icons") },
	{ _T("IconsSharedWin"), _T("Shared Files window icons") },
	{ _T("IconsTray"), _T("Tray icons") },
	{ _T("IconsTrayMenu"), _T("Tray menu icons") },
	{ _T("IconsPreviewDlg"), _T("Preview dialog icons") },
	{ _T("IconsChat"), _T("Message/Chat dialog icons") },
	{ _T("IconsFileMenu"), _T("File menu icons") },
	{ _T("IconsEditMenu"), _T("Edit menu icons") },
	{ _T("IconsFileInfoDlg"), _T("File info dialog icons") },
	{ _T("IconsServerMenu"), _T("Server menu icons") },
	{ _T("IconsStatsMenu"), _T("Statistics menu icons") },
	{ _T("IconsPriority"), _T("Priority icons") },
	{ _T("IconsEd2kLinks"), _T("Ed2k links related icons") },
	{ _T("IconsCollection"), _T("eMule collection icons") },
	{ _T("IconsIRCTextFormat"), _T("IRC text format icons") },
	{ _T("IconsSmilies"), _T("Smilies icons") },
	{ _T("IconsOthers"), _T("Other icons in eMule") },
	{ _T("IconsMod_AllMods"), _T("Mods' icons") },
	{ _T("IconsMod_hebMule"), _T("hebMule mod icons") },
	{ _T("IconsMod_Morph"), _T("Morph mod icons") },
	{ _T("IconsMod_SharkX"), _T("SharkX mod icons") },
	{ _T("IconsMod_StulleMule"), _T("StulleMule mod icons") },
	{ _T("IconsMod_Beba"), _T("Beba mod icons") },
	{ _T("IconsMod_Xtreme"), _T("Xtreme mod icons") },
	{ _T("IconsMod_MagicAngel"), _T("MagicAngel mod icons") },
	{ _T("IconsMod_NextEMF"), _T("NextEMF mod icons") },
	{ _T("BitmapAbout"), _T("About image") },
	{ _T("BitmapMainToolbar"), _T("Main toolbar image") },
	{ _T("HtmlMinimule"), _T("MiniMule HTML page") },
	{ NULL, NULL }
};

class CLanguage
{
 public:
	CLanguage();
	~CLanguage();

	void SetLang(LANGID lid);
	void SetLangDir(const CString& langdir);
	LANGID GetLang();

	CString GetString(const CString& str);
	CString GetLangLocalName(LANGID lid);
	CString GetLangCode(LANGID lid);
	void GetAvailableLangs(CLangArray &langs);
	bool IsLangSupported(LANGID lid);
	bool CheckLangVersion(LANGID lid);
	bool DownloadLang(LANGID lid);

 protected:
	bool Init();
	CString GetString(const CString& str, LANGID lid);
	void SetString(const CString& str, const CString& value, LANGID lid);
	CString GetLangNameByID(LANGID lid);
	CString GetLangFileByName(const CString& name);
	CString GetLangFileByID(LANGID lid);
	void CreateLangFile();

 private:
	CString m_strLangDir;
	LANGID m_langID;
};

extern CLanguage theLang;

