//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "Skinner.h"
#include "Preferences.h"
#include "ini2.h"
#include "version.h"
#include "Lang.h"
#include "functions.h"


CPreferences thePrefs;

bool CPreferences::confirmexit;
bool CPreferences::usenetconns;
bool CPreferences::check4update;
uint64 CPreferences::compatiblemods;
CString CPreferences::skinname;
CString CPreferences::skinprofile;
CString CPreferences::skinprofiledir;
bool CPreferences::skinprofile_loaded;
bool CPreferences::skinprofile_saved;
CString CPreferences::strMulePath;
CString CPreferences::strMuleConfigFile; // not stored!!!
DWORD CPreferences::dwWinVer; // not stored!

CPreferences::CPreferences()
{
}

CPreferences::~CPreferences()
{
}

void CPreferences::Init()
{
	// get application directory
	TCHAR buffer[MAX_PATH];
	::GetModuleFileName(0, buffer, ARRSIZE(buffer));
	LPTSTR pszFileName = _tcsrchr(buffer, _T('\\')) + 1;
	*pszFileName = _T('\0');
	appdir = buffer;
	theLang.SetLangDir(appdir+_T("lang\\"));
	dwWinVer = DetectWinVersion();

	Load();
}

void CPreferences::Uninit()
{
	Save();
}

void CPreferences::Load()
{
	CString inipath;
	inipath.Format(_T("%sSkinner.ini"), appdir);

	CIni ini(inipath, _T("Skinner"));

	skinnerver = ini.GetStringUTF8(_T("SkinnerVer"), theApp.GetVersionStr());
	if (!theLang.GetLang())
	{
		LANGID lid = ini.GetWORD(_T("LanguageID"), (LANGID)::GetThreadLocale());
		if (!theLang.IsLangSupported(lid))
			lid = LANGID_EN_US;
		theLang.SetLang(lid);
	}
	confirmexit = ini.GetBool(_T("ConfirmExit"), false);
	usenetconns = ini.GetBool(_T("UseNetConnections"), false);
	check4update = ini.GetBool(_T("CheckForNewVersion"), true);
	compatiblemods = ini.GetUInt64(_T("CompatibleMods"), 0);
	skinname = ini.GetStringUTF8(_T("SkinName"), _T(""));
	if (!skinname.IsEmpty())
		theApp.defSkin.SetAt(_T("Skinfo_SkinName"), skinname);
	SetSkinProfile(ini.GetStringUTF8(_T("SkinProfile"), _T("")));
	SetSkinProfileDir(ini.GetStringUTF8(_T("SkinProfileDir"), appdir + _T("Skins\\")));
	skinprofile_loaded = ini.GetBool(_T("SkinProfileLoaded"), false);
	skinprofile_saved = ini.GetBool(_T("SkinProfileSaved"), false);

	strMulePath = ini.GetStringUTF8(_T("eMulePath"), _T(""));
	if (strMulePath.IsEmpty() || !PathFileExists(strMulePath) || strMulePath.Right(4).CompareNoCase(_T(".exe")) != 0)
		strMulePath = FindMulePath();
	strMuleConfigFile = GetMuleConfigFilePath(); // uses thePrefs.strMulePath so must call after

	if (usenetconns && check4update && CheckForNewVersion())
	{
		int dlgselect = AfxMessageBox(GetResString(IDS_DETECTEDNEWVERSION), MB_YESNOCANCEL);
		if (dlgselect == IDYES)
			theApp.ShowHelp(_T("#changelog"));
		else if (dlgselect == IDCANCEL)
			check4update = false;
	}
	skinnerver = theApp.GetVersionStr();

	bool bSkinEditor = (bool)(!ini.GetBool(_T("DisableSkinEditor"), false));
	ApplySkinfileReg(bSkinEditor);
}

void CPreferences::Save()
{
	CString inipath;
	inipath.Format(_T("%sSkinner.ini"), appdir);

	CIni ini(inipath, _T("Skinner"));

	ini.WriteStringUTF8(_T("SkinnerVer"), skinnerver);
	ini.WriteWORD(_T("LanguageID"), theLang.GetLang());
	ini.WriteBool(_T("ConfirmExit"), confirmexit);
	ini.WriteBool(_T("UseNetConnections"), usenetconns);
	ini.WriteBool(_T("CheckForNewVersion"), check4update);
	ini.WriteUInt64(_T("CompatibleMods"), compatiblemods);
	ini.WriteStringUTF8(_T("SkinName"), skinname);
	ini.WriteStringUTF8(_T("SkinProfile"), skinprofile);
	ini.WriteStringUTF8(_T("SkinProfileDir"), skinprofiledir);
	ini.WriteBool(_T("SkinProfileLoaded"), skinprofile_loaded);
	ini.WriteBool(_T("SkinProfileSaved"), skinprofile_saved);
	ini.WriteStringUTF8(_T("eMulePath"), strMulePath);
}

const bool CPreferences::IsModCompatible(uint64 mod)
{
	return ((compatiblemods & mod) != 0);
}

void CPreferences::SetModCompatible(uint64 mod, bool bCompat)
{
	if (bCompat)
		compatiblemods |= mod;
	else
		compatiblemods &= ~mod;
}

CString CPreferences::GetSkinFileName(const CString& strName)
{
	CString buffer = appdir;
	if (!skinprofiledir.IsEmpty())
		buffer = skinprofiledir;
	buffer += (!strName.IsEmpty()) ? strName + _T(".") : (!skinname.IsEmpty() ? skinname + _T(".") : _T("Untitled."));
	buffer += EMULESKIN_BASEEXT;
 	return buffer;
}

void CPreferences::SetSkinProfileDir(const CString& strPath)
{
	skinprofiledir = strPath;
	if (strPath.GetLength() && strPath.Right(1) != _T('\\'))
		skinprofiledir += _T('\\');
	if (!PathFileExists(skinprofiledir))
		::CreateDirectory(skinprofiledir, 0);
}

bool CPreferences::SkinProfileSettings()
{
	return (skinprofile_saved || skinprofile_loaded || !skinname.IsEmpty() || !skinprofile.IsEmpty() || !skinprofiledir.IsEmpty());
}

bool CPreferences::CheckForNewVersion()
{
	if (!usenetconns)
		return false;

	CArray<char> acVer;
	if (!ReadNetFile(_T("versioncheck.php?app=skinner"), acVer))
		return false;
	CString strVer((LPSTR)acVer.GetData());
	uint32 curVer = MakeVersion(), testVer = MakeVersion(strVer);
	return (curVer > 0 && testVer > 0 && curVer < testVer);
}

