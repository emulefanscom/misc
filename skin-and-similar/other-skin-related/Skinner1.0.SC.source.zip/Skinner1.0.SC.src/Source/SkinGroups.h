//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#pragma once

typedef struct skinGroup
{
	LPCTSTR pszName;
	LPCTSTR aItems[45]; // currently support up to 45 items, todo: make it dynamic
} skinGroup;

typedef struct skinSection
{
	LPCTSTR pszName;
	const skinGroup* aGroups;
} skinSection;

typedef struct modsInfo
{
	uint64 uID;
	LPCTSTR pszName;
} ModsInfo;


static const skinGroup _sectionColors[] = {
	{ _T("ColorsDefault"), { _T("DefLvBk"), _T("DefLvFg"), _T("DefLvHl"), NULL } },
	{ _T("ColorsServer"), { _T("ServersLvBk"), _T("ServersLvFg"), _T("ServersLvHl"), NULL } },
	{ _T("ColorsSearchResult"), { _T("SearchResultsLvBk"), _T("SearchResultsLvFg"), _T("SearchResultsLvHl"), _T("SearchResultsLvFg_Downloading"), _T("SearchResultsLvFg_DownloadStopped"), _T("SearchResultsLvFg_Sharing"), _T("SearchResultsLvFg_Known"), _T("SearchResultsLvFg_AvblyBase"), NULL } },
	{ _T("ColorsDownload"), { _T("DownloadsLvBk"), _T("DownloadsLvFg"), _T("DownloadsLvHl"), NULL } },
	{ _T("ColorsUpload"), { _T("UploadsLvBk"), _T("UploadsLvFg"), _T("UploadsLvHl"), NULL } },
	{ _T("ColorsQueue"), { _T("QueuedLvBk"), _T("QueuedLvFg"), _T("QueuedLvHl"), NULL } },
	{ _T("ColorsClients"), { _T("ClientsLvBk"), _T("ClientsLvFg"), _T("ClientsLvHl"), NULL } },
	{ _T("ColorsFriends"), { _T("FriendsLvBk"), _T("FriendsLvFg"), _T("FriendsLvHl"), NULL } },
	{ _T("ColorsIRCnick"), { _T("IRCNicksLvBk"), _T("IRCNicksLvFg"), _T("IRCNicksLvHl"), NULL } },
	{ _T("ColorsIRCchannels"), { _T("IRCChannelsLvBk"), _T("IRCChannelsLvFg"), _T("IRCChannelsLvHl"), NULL } },
	{ _T("ColorsShared"), { _T("SharedFilesLvBk"), _T("SharedFilesLvFg"), _T("SharedFilesLvHl"), NULL } },
	{ _T("ColorsKadContact"), { _T("KadContactsLvBk"), _T("KadContactsLvFg"), _T("KadContactsLvHl"), NULL } },
	{ _T("ColorsKadAction"), { _T("KadActionsLvBk"), _T("KadActionsLvFg"), _T("KadActionsLvHl"), NULL } },
	{ _T("ColorsStats"), { _T("StatisticsTvBk"), _T("StatisticsTvFg"), NULL } },
	{ _T("ColorsLogWin"), { _T("LogBk"), _T("LogFg"), NULL } },
	{ _T("ColorsVerboseLogWin"), { _T("VerboseLogBk"), _T("VerboseLogFg"), NULL } },
	{ _T("ColorsServerLogWin"), { _T("ServerInfoLogBk"), _T("ServerInfoLogFg"), NULL } },
	{ _T("ColorsChatWin"), { _T("ChatBk"), _T("ChatFg"), NULL } },
	{ _T("ColorsIRCWin"), { _T("IRCChannelBk"), _T("IRCChannelFg"), NULL } },
	{ NULL, NULL }
};

static skinGroup _sectionIcons[] = {
	{ _T("IconsToolbar"), { _T("Connect"), _T("Disconnect"), _T("StopConnecting"), _T("Kademlia"), _T("Server"), _T("Transfer"), _T("Search"), _T("SharedFiles"), _T("Messages"), _T("IRC"), _T("Statistics"), _T("Preferences"), _T("Tools"), _T("Help"), NULL } },
	{ _T("IconsPrefs"), { _T("Display"), _T("Connection"), _T("Proxy"), _T("Folders"), _T("Notifications"), _T("Scheduler"), _T("Security"), _T("Tweak"), _T("Web"), NULL } },
	{ _T("IconsClients"), { _T("ClientEdonkey"), _T("ClientEdonkeyPlus"), _T("ClientCompatible"), _T("ClientCompatiblePlus"), _T("ClientEdonkeyHybrid"), _T("ClientEdonkeyHybridPlus"), _T("ClientMldonkey"), _T("ClientMldonkeyPlus"), _T("ClientShareaza"), _T("ClientShareazaPlus"), _T("ClientAMule"), _T("ClientAMulePlus"), _T("ClientLPhant"), _T("ClientLPhantPlus"), _T("ClientSecureOvl"), _T("OverlayObfu"), _T("OverlaySecureObfu"), NULL } },
	{ _T("IconsSources"), { _T("SrcConnecting"), _T("SrcDownloading"), _T("SrcNnpQf"), _T("SrcOnQueue"), _T("SrcUnknown"), NULL } },
	{ _T("IconsFileRates"), { _T("Rating_NotRated"), _T("Rating_Fake"), _T("Rating_Poor"), _T("Rating_Fair"), _T("Rating_Good"), _T("Rating_Excellent"), NULL } },
	{ _T("IconsFriends"), { _T("Friend"), _T("FriendConnected"), _T("FriendNoClient"), _T("FriendWithClient"), NULL } },
	{ _T("IconsFriendsMenu"), { _T("AddFriend"), _T("DeleteFriend"), _T("FriendSlot"), _T("ViewFiles"), _T("SendMessage"), _T("ClientDetails"), NULL } },
	{ _T("IconsKadWin"), { _T("KadBootstrap"), _T("KadContactList"), _T("KadCurrentSearches"), NULL } },
	{ _T("IconsKadSearch"), { _T("KadFileSearch"), _T("KadNodeSearch"), _T("KadStoreFile"), _T("KadStoreWord"), _T("KadWordSearch"), NULL } },
	{ _T("IconsKadContact"), { _T("Contact0"), _T("Contact1"), _T("Contact2"), _T("Contact3"), _T("Contact4"), NULL } },
	{ _T("IconsSearchWin"), { _T("SearchParams"), _T("SearchResults"), NULL } },
	{ _T("IconsSearchMethod"), { _T("KadServer"), _T("SearchMethod_Server"), _T("SearchMethod_Global"), _T("SearchMethod_Kademlia"), _T("SearchMethod_ServerActive"), _T("SearchMethod_GlobalActive"), _T("SearchMethod_KademliaActive"), _T("SearchMethod_FileDonkey"), NULL } },
	{ _T("IconsSearchFileTypes"), { _T("SearchFileType_Any"), _T("SearchFileType_Archive"), _T("SearchFileType_Audio"), _T("SearchFileType_CDImage"), _T("SearchFileType_Picture"), _T("SearchFileType_Program"), _T("SearchFileType_Video"), _T("SearchFileType_Document"), _T("SearchFileType_eMuleCollection"), NULL } },
	{ _T("IconsStatsWin"), { _T("StatsClients"), _T("StatsCumulative"), _T("StatsDetail"), _T("StatsGeneric"), _T("StatsProjected"), _T("StatsRecords"), _T("StatsTime"), _T("StatsDay"), _T("StatsMonth"), _T("StatsYear"), _T("Harddisk"), NULL } },
	{ _T("IconsStatusbar"), { _T("ConnectedNotNot"), _T("ConnectedNotLow"), _T("ConnectedNotHigh"), _T("ConnectedLowNot"), _T("ConnectedLowLow"), _T("ConnectedLowHigh"), _T("ConnectedHighNot"), _T("ConnectedHighLow"), _T("ConnectedHighHigh"), _T("Up0Down0"), _T("Up0Down1"), _T("Up1Down0"), _T("Up1Down1"), _T("TransferUpDown"), _T("Download"), _T("Upload"), NULL } },
	{ _T("IconsServerWin"), { _T("ServerList"), _T("ServerInfo"), _T("ServerUpdateMet"), _T("AddServer"), _T("Info"), _T("Log"), NULL } },
	{ _T("IconsTransferWin"), { _T("ClientsOnQueue"), _T("ClientsKnown"), _T("SplitWindow"), _T("DownloadFiles"), NULL } },
	{ _T("IconsSharedWin"), { _T("SharedFilesList"), _T("FileSharedServer"), _T("FileSharedKad"), _T("AllFiles"), _T("Incomplete"), _T("Incoming"), _T("FileCommentsOvl"), _T("SharedFolderOvl"), NULL } },
	{ _T("IconsTray"), { _T("TrayConnected"), _T("TrayLowID"), _T("TrayNotConnected"), NULL } },
	{ _T("IconsTrayMenu"), { _T("Speed"), _T("SpeedMin"), _T("SpeedMax"), _T("RestoreWindow"), _T("Exit"), NULL } },
	{ _T("IconsPreviewDlg"), { _T("Back"), _T("Forward"), _T("Cancel"), NULL } },
	{ _T("IconsChat"), { _T("Chat"), _T("Message"), _T("MessagePending"), NULL } },
	{ _T("IconsFileMenu"), { _T("Rename"), _T("Pause"), _T("Resume"), _T("Stop"), _T("Delete"), _T("Preview"), _T("ClearComplete"), _T("Restore"), _T("OpenFile"), _T("OpenFolder"), NULL } },
	{ _T("IconsEditMenu"), { _T("Copy"), _T("CopySelected"), _T("CopyVisible"), _T("DeleteSelected"), NULL } },
	{ _T("IconsFileInfoDlg"), { _T("FileInfo"), _T("FileComments"), _T("MediaInfo"), _T("MetaData"), _T("Archive_Preview"), _T("FileRename"), NULL } },
	{ _T("IconsServerMenu"), { _T("ListAdd"), _T("ListRemove"), NULL } },
	{ _T("IconsStatsMenu"), { _T("ExportAll"), _T("Collapse"), _T("ExpandMain"), _T("ExpandAll"), NULL } },
	{ _T("IconsPriority"), { _T("Priority"), _T("Prio_Normal"), _T("Prio_Auto"), _T("Prio_High"), _T("Prio_Low"), _T("FilePriority"), NULL } },
	{ _T("IconsEd2kLinks"), { _T("PasteLink"), _T("eD2kLink"), _T("IrcClipboard"), NULL } },
	{ _T("IconsCollection"), { _T("Collection"), _T("aabCollectionFileType"), _T("Collection_View"), _T("Collection_Add"), _T("Collection_Edit"), _T("Collection_Search"), NULL } },
	{ _T("IconsSmilies"), { _T("Smiley_cry"), _T("Smiley_disgust"), _T("Smiley_happy"), _T("Smiley_interest"), _T("Smiley_laugh"), _T("Smiley_love"), _T("Smiley_ph34r"), _T("Smiley_sad"), _T("Smiley_sealed"), _T("Smiley_skeptic"), _T("Smiley_smile"), _T("Smiley_tongue"), _T("Smiley_wink"), NULL } },
	{ _T("IconsIRCTextFormat"), { _T("Colour"), _T("Bold"), _T("Underline"), _T("ResetFormat"), NULL } },
	{ _T("IconsOthers"), { _T("CloseTab"), _T("CloseTabSelected"), _T("Convert"), _T("IPFilter"), _T("Wizard"), _T("Category"), _T("SearchEdit"), _T("FilterClear1"), _T("FilterClear2"), _T("Warning"), _T("Spam"), _T("Empty"), NULL } },

	// mods (todo: create dynamically added mods)
	{ _T("IconsMod_AllMods"), { _T("hebMule"), _T("Morph"), _T("SharkX"), _T("Stulle"), _T("Beba"), _T("MagicAngel"), _T("EastShare"), _T("eMulEspana"), _T("Emf"), _T("Neo"), _T("Xtreme"), _T("ScarAngel"), _T("Mephisto"), _T("Xray"), NULL } },
	{ _T("IconsMod_hebMule"), { _T("hebMule"), _T("AntiVirus"), _T("AntiLeech"), _T("Search_Hebrew"), _T("Search_English"), _T("Search_MultiLingual"), _T("OpenWebSite"), _T("aaceMuleSkinFile"), NULL } },
	{ _T("IconsMod_Morph"), { _T("Morph"), _T("aabIncomingFolder"), _T("Suc"), _T("ClientRightEDonkey"), _T("ClientCreditOvl"), _T("ClientCreditSecureOvl"), _T("Backup"), _T("Community"), _T("ClientFriendOvl"), _T("ClientFriendSlotOvl"), _T("FriendNoClientSlot"), _T("FriendWithClientSlot"), _T("FriendConnectedSlot"), _T("Mobile"), _T("UPnP"), _T("FilePermission"), _T("FileMassRename"), _T("FileCrc32"), _T("FilePowerShare"), _T("FileHideOS"),
		_T("FileShareOnlyTheNeed"), _T("FileRequested"), _T("FileSpreadBar"), _T("FileAddSrc"), _T("FileDownload"), _T("FileDownloadPaused"), _T("FileDownloadPreviewFirst"), _T("FileLinearPrio"), _T("FileImportParts"), _T("FileInitiateRehash"), _T("AdvA4Af"), _T("CatStopLast"), _T("CatPauseLast"), _T("CatResumeNext"), _T("CatAdd"), _T("CatEdit"), _T("CatRemove"), _T("CatMerge"), _T("FriendSlotRemove"), _T("ZZratio"), NULL } },
	{ _T("IconsMod_SharkX"), { _T("Taz"), _T("BadGuy"), _T("Emulate"), _T("Sls"), _T("DisSimilar_Name"), _T("HeaderDetail"), _T("Up1Down1_S"), _T("Up1Down0_S"), _T("Up0Down1_S"), _T("Friend_S"), _T("StatsClients_S"), _T("DropDefaults"), _T("FunnyNick"), _T("KadBuddySearch"), _T("KadStoreNote"), _T("KadNoteSearch"), _T("NodesUpdateDat"), _T("DLmode"), NULL } },
	{ _T("IconsMod_StulleMule"), { _T("MiniMule"), _T("TrayConnectedPlus"), _T("TrayNotConnectedPlus"), _T("TrayLowIdPlus"),_T("EmulateIcon"), _T("NotShared"), _T("Save"), _T("Cut"), _T("Undo"), _T("Paste"), _T("SchedulerAdd"), _T("SchedulerRemove"), _T("SchedulerEdit"), _T("Update"), _T("Edit"), _T("New"), _T("ReleaseBonus"), _T("SpreadCredits"), _T("Pinger"), _T("MM_ConCon"), _T("MM_ConLow"), _T("MM_ConDis"), _T("MM_LowCon"), _T("MM_LowLow"), _T("MM_LowDis"), _T("MM_DisCon"), _T("MM_DisLow"), _T("MM_DisDis"), _T("IDI_FontUL"), _T("IDI_FontI"), _T("IDI_FontB"), NULL } },
	{ _T("IconsMod_Beba"), { _T("Beba"), _T("BadGuy"), _T("DropMenu"), _T("HardLimit"), _T("DisSimilar_Name"), _T("Emulate"), _T("FriendSlotRemove"), _T("MiscTweaks"), _T("DropNNS"), _T("DropFQ"), _T("DropTM"), _T("DropUN"), _T("Src_A4AF"), _T("KadNoteSearch"), _T("KadStoreNote"), _T("KadBuddySearch"), _T("Reask"), _T("UPnP"), _T("Sls"), _T("MiniMule"), _T("ReleaseBonus"), NULL } },
	{ _T("IconsMod_Xtreme"), { _T("Xtreme"), _T("ClientFriendSlotOvl"), _T("FriendNoClientSlot"), _T("FriendWithClientSlot"), _T("FriendConnectedSlot"), _T("FileMassRename"), _T("DropIcon"), _T("Leecher"), _T("FileRequested"), _T("ClientMLDonkeyPlus1"), NULL } },
	{ _T("IconsMod_MagicAngel"), { _T("Leecher"), _T("Messages2"), _T("Preferences2"), _T("ReleaseBoost"), _T("Search2"), _T("Server2"), _T("Statistics2"), _T("Transfer2"), _T("IRC2"), _T("AngelArgos"), _T("AngelArgosPunishment"), _T("AngelArgosGeneral"), _T("Reask"), _T("QuickStart"), _T("ColoredUpload"), _T("PushFiles"), _T("OtherSettings"), NULL } },
	{ _T("IconsMod_NextEMF"), { _T("Emf"), _T("BadGuy"), _T("HardLimit"), _T("Display2"), _T("Drop"), _T("KadNoteSearch"), _T("KadStoreNote"), _T("KadBuddySearch"), NULL } },

	{ NULL, NULL }
};

static const skinGroup _sectionBitmaps[] = {
	{ _T("BitmapAbout"), { _T("About"), NULL } },
	{ _T("BitmapMainToolbar"), { _T("MainToolBarBk"), NULL } },
	{ NULL, NULL }
};

static const skinGroup _sectionHTML[] = {
	{ _T("HtmlMinimule"), { _T("MiniMule"), NULL } },
	{ NULL, NULL }
};

static const skinGroup _sectionSkinfo[] = {
	{ _T("Skinfo"), { _T("Skinfo_Author"), _T("Skinfo_SkinName"), _T("Skinfo_SkinVersion"), NULL } },
	{ NULL, NULL }
};


static const skinSection _skinInfo[] = {
	{ _T("Colors"),	_sectionColors },
	{ _T("Icons"),	_sectionIcons },
	{ _T("Bitmaps"),	_sectionBitmaps },
	{ _T("HTML"),	_sectionHTML },
	{ _T("Separator"),	NULL },
	{ _T("Skinfo"),	_sectionSkinfo },
	{ NULL, NULL }
};


#define MOD_ALLMODS		0xFFFF
#define MOD_HEBMULE		0x0001
#define MOD_MORPH		0x0008
#define MOD_SHARKX		0x0010
#define MOD_STULLEMULE		0x0020
#define MOD_BEBA		0x0040
#define MOD_XTREME		0x0080
#define MOD_MAGICANGEL		0x0100
#define MOD_NEXTEMF		0x0200

static const ModsInfo _aMods[] = {
	{ MOD_ALLMODS,		_T("AllMods") },
	{ MOD_HEBMULE,		_T("hebMule") },
	{ MOD_MORPH,		_T("Morph") },
	{ MOD_SHARKX,		_T("SharkX") },
	{ MOD_STULLEMULE,	_T("StulleMule") },
	{ MOD_BEBA,		_T("Beba") },
	{ MOD_XTREME,		_T("Xtreme") },
	{ MOD_MAGICANGEL,	_T("MagicAngel") },
	{ MOD_NEXTEMF,		_T("NextEMF") }
};

static const int _aModsSize = sizeof(_aMods) / sizeof(_aMods[0]);

