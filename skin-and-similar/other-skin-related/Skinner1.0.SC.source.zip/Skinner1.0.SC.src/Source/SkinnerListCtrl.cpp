//this file is part of eMule Skinner
//Copyright (C)2003-2008 Avi3k ( strEmail.Format("%s@%s", "hebmule", "gmail.com") / http://hebmule.sf.net )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#include "stdafx.h"
#include "SkinnerListCtrl.h"
#include "Skinner.h"
#include "SkinnerDlg.h"
#include "Lang.h"
#include "MenuEx.h"
#include "functions.h"

#define LV_EDIT_COL		1
#define LV_EDIT_CTRL_ID		1001
#ifndef LVN_BEGINSCROLL
#define LVN_BEGINSCROLL          (LVN_FIRST-80)
#endif

CSkinnerListCtrl::CSkinnerListCtrl()
{
	m_strValType = _T("Colors");
	m_pEdit = NULL;
	m_iEditRow = m_iEditCol = -1;
}

CSkinnerListCtrl::~CSkinnerListCtrl()
{
	if (m_pEdit)
		delete m_pEdit;
	m_iconList.DeleteImageList();
	if (m_menuEntry)
		VERIFY( m_menuEntry.DestroyMenu() );
}


BEGIN_MESSAGE_MAP(CSkinnerListCtrl, CListCtrl)
	ON_WM_CONTEXTMENU()
	ON_WM_DESTROY()
	ON_EN_KILLFOCUS(LV_EDIT_CTRL_ID, OnEnKillFocus)
	ON_WM_LBUTTONDOWN()
	ON_WM_SETFOCUS()
	ON_NOTIFY_REFLECT(LVN_BEGINSCROLL, OnLvnBeginScroll)
	ON_MESSAGE(UM_CPN_SELENDOK, OnColorPopupEndOK)
END_MESSAGE_MAP()


void CSkinnerListCtrl::InitListCtrl()
{
	SetExtendedStyle(LVS_EX_FULLROWSELECT);
	ModifyStyle(LVS_SINGLESEL, 0);
	InsertColumn(colEntry, _T("Entry"), LVCFMT_LEFT, 200);
	InsertColumn(colValue, m_strValType, LVCFMT_LEFT, 225);

	SetAllIcons();
}

void CSkinnerListCtrl::Localize()
{
	CHeaderCtrl* pColorHeaderCtrl = GetHeaderCtrl();
	HDITEM hdi;
	hdi.mask = HDI_TEXT;
	CString strRes;

	CHeaderCtrl* pHeaderCtrl = GetHeaderCtrl();
	for (int iCol = 0; iCol < pHeaderCtrl->GetItemCount(); iCol++)
	{
		switch (iCol)
		{
			case colEntry: strRes = GetResString(IDS_ENTRY); break;
			case colValue: strRes = theLang.GetString(m_strValType); break;
			default: strRes = _T("");
		}
		hdi.pszText = const_cast<LPTSTR>((LPCTSTR)strRes);
		pColorHeaderCtrl->SetItem(iCol, &hdi);
	}

	CreateMenues();
}

void CSkinnerListCtrl::InsertItem(const CString& strEntry, const CString& strValue, DWORD_PTR dwData)
{
	int nIndex = CListCtrl::InsertItem(GetItemCount(), strEntry, GetDisplayIconIndex(strEntry));
	SetItemText(nIndex, colValue, strValue);
	SetItemData(nIndex, dwData);
}


void CSkinnerListCtrl::OnContextMenu(CWnd* pWnd, CPoint point)
{
	int iSel = GetSelectionMark(), iCount = GetSelectedCount();

	m_menuEntry.SetDefaultItem(MP_OPENDLG);
	m_menuEntry.EnableMenuItem(MP_OPENDLG, (iSel != -1 && iCount == 1) ? MF_ENABLED : MF_GRAYED);
	m_menuEntry.EnableMenuItem(MP_COPY, (iSel != -1 && iCount > 0) ? MF_ENABLED : MF_GRAYED);
	m_menuEntry.EnableMenuItem(MP_PASTE, (!theApp.CopyTextFromClipboard().IsEmpty()) ? MF_ENABLED : MF_GRAYED);
	m_menuEntry.EnableMenuItem(MP_CLEAR, (iSel != -1 && iCount > 0) ? MF_ENABLED : MF_GRAYED);

	if (point.x == -1 && point.y == -1) // for Context menu/Shift+F10 keys
	{
		point.x = point.y = 16;
		ClientToScreen(&point);
	}
	m_menuEntry.TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);
}

void CSkinnerListCtrl::CreateMenues()
{
	if (m_menuEntry)
		VERIFY( m_menuEntry.DestroyMenu() );

	m_menuEntry.CreatePopupMenu();
	m_menuEntry.AppendMenu(MF_STRING, MP_OPENDLG, GetResString(IDS_OPENDLG)+_T("\tCtrl+O"), _T("OpenFile"));
	//m_menuEntry.AppendMenu(MF_STRING, MP_REMOVE, GetResString(IDS_REMOVESTRING));
	m_menuEntry.AppendMenu(MF_STRING, MP_COPY, GetResString(IDS_COPY)+_T("\tCtrl+C"), _T("Copy"));
	m_menuEntry.AppendMenu(MF_STRING, MP_PASTE, GetResString(IDS_PASTE)+_T("\tCtrl+V"), _T("Paste"));
	m_menuEntry.AppendMenu(MF_STRING, MP_CLEAR, GetResString(IDS_CLEAR)+_T("\tDel"), _T("Delete"));
	m_menuEntry.AppendMenu(MF_SEPARATOR);
	m_menuEntry.AppendMenu(MF_STRING, MP_SELECTALL, GetResString(IDS_SELECTALL)+_T("\tCtrl+A"), _T("ExportAll"));
}

BOOL CSkinnerListCtrl::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch (LOWORD(wParam))
	{
		case MP_OPENDLG:
		case MP_REMOVE:
		case MP_PASTE:
		case MP_CLEAR:
		{
			GetParent()->SendMessage(WM_COMMAND, wParam, lParam);
			return true;
		}
		case MP_COPY:
		case MP_TB_COPY:
		{
			CString cbt;
			POSITION pos = GetFirstSelectedItemPosition();
			while (pos)
			{
				int itemPos = GetNextSelectedItem(pos);
				cbt.AppendFormat(_T("%s=%s\r\n"), GetItemText(itemPos, colEntry), GetItemText(itemPos, colValue));
			}
			theApp.CopyTextToClipboard(cbt);
			GetParent()->SendMessage(WM_COMMAND, MP_UPDATE_TBBTNS);
			return true;
		}
		case MP_SELECTALL:
		case MP_TB_SELECTALL:
		{
			for (int i = 0; i < GetItemCount(); i++)
				SetItemState(i, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
			GetParent()->SendMessage(WM_COMMAND, MP_UPDATE_TBBTNS);
			SetFocus();
			return true;
		}
	}
	return CListCtrl::OnCommand(wParam, lParam);
}

void CSkinnerListCtrl::SetAllIcons()
{
	m_iconList.DeleteImageList();
	m_iconList.Create(16, 16, GetAppImageListColorFlag() | ILC_MASK, 0, 1);
	m_iconList.SetBkColor(CLR_NONE);
	m_idxIcons.RemoveAll();
	m_idxIcons.InitHashTable(223);
	for (int i = 0; i < ARRSIZE(_sectionIcons); i++)
	{
		for (LPCTSTR* paEntry = (LPCTSTR*)_sectionIcons[i].aItems; paEntry && *paEntry; paEntry++)
			m_idxIcons[*paEntry] = (int)m_iconList.Add(CTempIconLoader(*paEntry, 16, 16));
	}
	SetImageList(&m_iconList, LVSIL_SMALL);
}

int CSkinnerListCtrl::GetDisplayIconIndex(const CString& strEntry)
{
	int nIndex = -1;
	m_idxIcons.Lookup(strEntry, nIndex);
	return nIndex;
}

LRESULT CSkinnerListCtrl::OnColorPopupEndOK(WPARAM wParam, LPARAM lParam)
{
	GetParent()->SendMessage(UM_CPN_SELENDOK, wParam, lParam);
	return TRUE;
}

void CSkinnerListCtrl::OnSetFocus(CWnd* pOldWnd)
{
	CListCtrl::OnSetFocus(pOldWnd);

	if (m_iEditCol == LV_EDIT_COL && pOldWnd != m_pEdit)
		ShowEditCtrl();
}

void CSkinnerListCtrl::CommitEditCtrl()
{
	if (m_iEditCol == -1 || m_iEditRow == -1 || !m_pEdit || !m_pEdit->IsWindowVisible())
		return;
	CString strItem;
	m_pEdit->GetWindowText(strItem);
	strItem.Trim();
	SetItemText(m_iEditRow, LV_EDIT_COL, strItem);
	GetParent()->SendMessage(WM_COMMAND, MP_EDIT, m_iEditRow);
	m_iEditRow = m_iEditCol = -1;
}

void CSkinnerListCtrl::ShowEditCtrl()
{
	static const DWORD dwFlags = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_TABSTOP | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL;
	if (m_iEditRow < 0)
		m_iEditRow = GetSelectionMark();
	if (m_iEditRow >= GetItemCount() || m_iEditRow < 0)
		return;

	CRect rect;
	GetSubItemRect(m_iEditRow, LV_EDIT_COL, LVIR_LABEL, rect);
	if (m_pEdit == NULL)
	{
		m_pEdit = new CEdit;
		m_pEdit->Create(dwFlags, rect, this, LV_EDIT_CTRL_ID);
		m_pEdit->SetFont(GetFont());
		m_pEdit->ShowWindow(SW_SHOW);
	}
	else
	{
		m_pEdit->SetWindowPos(NULL, rect.left, rect.top, rect.Width(), rect.Height(), SWP_SHOWWINDOW);
	}

	m_pEdit->SetWindowText(GetItemText(m_iEditRow, LV_EDIT_COL));
	m_pEdit->SetSel(0, -1);
	m_pEdit->SetFocus();

	m_iEditCol = LV_EDIT_COL;
}

void CSkinnerListCtrl::OnEnKillFocus()
{
	CommitEditCtrl();
	m_iEditRow = m_iEditCol = -1;
	if (m_pEdit)
		m_pEdit->ShowWindow(SW_HIDE);
}

BOOL CSkinnerListCtrl::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
	{
		UINT nChar = (UINT)pMsg->wParam;
		if (nChar == VK_RETURN)
			OnEnKillFocus();
	}
	return CListCtrl::PreTranslateMessage(pMsg);
}

void CSkinnerListCtrl::OnLButtonDown(UINT nFlags, CPoint point)
{
	CListCtrl::OnLButtonUp(nFlags, point);
	GetParent()->SendMessage(WM_COMMAND, MP_UPDATE_TBBTNS);

	LVHITTESTINFO hti = {0};
	hti.pt = point;
	if (SubItemHitTest(&hti) == -1 || hti.iItem == -1)
		return;

	EnsureVisible(hti.iItem, false);
	if (hti.iSubItem != LV_EDIT_COL)
	{
		if (nFlags == MK_LBUTTON && GetSelectedCount() == 1)
			GetParent()->SendMessage(WM_COMMAND, MP_OPENDLG, (LPARAM)&point);
		return;
	}

	m_iEditRow = hti.iItem;
	m_iEditCol = LV_EDIT_COL;
	ShowEditCtrl();
}

void CSkinnerListCtrl::OnDestroy()
{
	delete m_pEdit;
	m_pEdit = NULL;
	CListCtrl::OnDestroy();
}

void CSkinnerListCtrl::OnLvnBeginScroll(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	m_iEditRow = m_iEditCol = -1;
	if (m_pEdit)
	{
		CommitEditCtrl();
		m_pEdit->ShowWindow(SW_HIDE);
	}
	*pResult = 0;
}
