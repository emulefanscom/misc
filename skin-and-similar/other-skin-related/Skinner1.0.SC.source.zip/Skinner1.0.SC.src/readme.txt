eMule Skinner � All rights reserved to Avi3k [hebMule.sf.net], 2003-2008
Version 1.0
_________________________________________________

This program is free software; you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software Foundation;
either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with 
this program; if not, write to the Free Software Foundation, Inc., 675 Mass 
Ave, Cambridge, MA 02139, USA.

_________________________________________________


eMule Skinner is a free app under the GNU GPL license. That means you must release the sources next to the binaries!
(see the license.txt file and/or license folder attached to this release)
all the Copyrights of Skinner reserved to Avi3k ( hebMule at gmail dot com )
you can find the Source Code of Skinner in the Source folder next to this file.

Skinner helps you to create skins for eMule, a free open-source file sharing program.
just select the section and the group from the lists, and Skinner will help you
modify the icons, colors and other sections of eMule's skin file.


currently Skinner supports English, Hebrew, Spanish, French, German, Italian, Portuguese, Danish, Polish, Czech and Dutch.
if you'd like to contribute, either by translating Skinner into another language,
or add support to you mod, contact me via email or via hebMule.sf.net site


for more information about Skinner, hebMule and help, visit http://hebMule.sf.net!
for more information about eMule, the Official client, visit http://www.eMule-Project.net!

*** Special thanks to eMule dev team for very useful code parts and for eMule itself! :-) ***

